// =========================================
// CreatorOS AI – AI Service
// Flexible AI provider integration
// Supports: Mock, OpenAI, Claude, DeepSeek, NVIDIA
// =========================================

import { ToolId, GenerateRequest, GenerateResponse, AppSettings } from '../types';

// ─── Mock Responses ──────────────────────────────────────────────────────────
// Used when no API key is configured

const MOCK_RESPONSES: Record<ToolId, (input: string) => string> = {
  'shorts-script': (input) => `🎬 VIRAL SHORTS SCRIPT – "${input}"
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

[HOOK – 0:00-0:05]
"Wait until you see this... Nobody talks about ${input} like THIS."

[BODY – 0:05-0:50]
Most people think ${input} is complicated. It's not.

Here's the 3-step method:

STEP 1 – Start before you're ready.
Everyone waits for the perfect moment. It never comes. Take action TODAY.

STEP 2 – Focus on the 20% that gives 80% results.
Stop wasting time on things that don't move the needle.

STEP 3 – Stay consistent for just 21 days.
That's all it takes to rewire your habits and see real results.

[CTA – 0:50-0:60]
"If this helped, FOLLOW for more tips like this. Drop a 🔥 in the comments if you're starting TODAY!"

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
📊 Estimated Duration: 58 seconds
🎯 Target Platform: YouTube Shorts / Instagram Reels
💡 Tip: Film this in portrait mode, add captions for accessibility`,

  'viral-hook': (input) => `🎣 VIRAL HOOKS – "${input}"
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

HOOK #1 – The Shocking Statement
"I ${input} for 30 days and nobody warned me about what happened next..."

HOOK #2 – The Question Hook
"What if everything you know about ${input} is completely wrong?"

HOOK #3 – The Contrarian Hook
"Unpopular opinion: The way 99% of people approach ${input} is killing their results."

HOOK #4 – The Story Hook
"3 years ago, I was struggling with ${input}. Then a stranger said 5 words that changed everything..."

HOOK #5 – The Curiosity Hook
"The secret to mastering ${input} that successful people refuse to share publicly."

HOOK #6 – The Warning Hook
"STOP doing this when it comes to ${input}. I wish someone told me this sooner."

HOOK #7 – The Social Proof Hook
"How 10,000+ people used this exact ${input} strategy to transform their results in 90 days."

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
💡 Best performing: Hook #1 and #3 (based on industry data)
🎯 Use in: Video intros, Social media posts, Email subjects`,

  'youtube-title': (input) => `▶️ YOUTUBE TITLES – "${input}"
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

HIGH-CTR TITLES:

1. 🔥 "${input}" – The TRUTH Nobody Is Telling You
2. I Tried ${input} For 30 Days... Here's What Happened
3. The ${input} Strategy That Changed My Life (Step-by-Step)
4. Why 99% of People FAIL at ${input} (And How to Be in the 1%)
5. ${input}: From Complete Beginner to EXPERT in 7 Days
6. WATCH BEFORE You Start ${input} – Critical Mistakes to Avoid
7. How I Used ${input} to Go From $0 to $10K in 30 Days
8. The Only ${input} Video You'll Ever Need to Watch
9. ${input} MASTERCLASS – Everything I Know in 15 Minutes
10. This ${input} Hack Went VIRAL for a Reason... (Try This!)

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
📈 CTR Optimization Tips:
• Keep titles under 60 characters for best display
• Use numbers (odd numbers perform 25% better)
• Add power words: TRUTH, SECRET, NEVER, FINALLY
• Include year for evergreen content`,

  'seo-description': (input) => `🔍 SEO DESCRIPTION – "${input}"
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

META DESCRIPTION (155 chars):
"Discover the complete guide to ${input}. Learn proven strategies, avoid common mistakes, and get results fast. Start your journey today!"

YOUTUBE DESCRIPTION:

In this video, I'll show you everything you need to know about ${input} – from beginner basics to advanced strategies that actually work in 2024.

🔥 WHAT YOU'LL LEARN:
✅ The fundamentals of ${input} (even if you're a complete beginner)
✅ Common mistakes that 90% of people make and how to avoid them
✅ My proven step-by-step system for getting results fast
✅ Real case studies and examples from my own experience
✅ Tools and resources I personally recommend

⏰ TIMESTAMPS:
0:00 – Introduction
1:30 – Why ${input} matters more than ever
4:00 – Step-by-step breakdown
8:45 – Real examples
12:00 – Top tools & resources
14:30 – Final tips & summary

🔗 RESOURCES MENTIONED:
→ Free toolkit: [link]
→ Full course: [link]

📌 RELATED KEYWORDS: ${input}, ${input} guide, ${input} tutorial, ${input} tips, how to ${input}, ${input} for beginners, best ${input} strategies

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
🎯 Primary keyword density: 2.3% (Optimal)
📊 Readability score: 78/100 (Good)`,

  'hashtag-generator': (input) => `#️⃣ HASHTAGS – "${input}"
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

🔥 HIGH REACH (1M+ posts):
#${input.replace(/\s+/g, '')} #ContentCreator #ViralContent #Trending #Fyp #ForYou #ReelsViral #ExploreMore #ViralVideo #CreatorCommunity

📈 MEDIUM REACH (100K-1M):
#${input.replace(/\s+/g, '')}Tips #${input.replace(/\s+/g, '')}Life #${input.replace(/\s+/g, '')}Community #CreativeMind #DigitalCreator #ContentStrategy #GrowthHacking #OnlineMarketing #SocialMediaTips

🎯 NICHE (10K-100K):
#${input.replace(/\s+/g, '')}Hacks #${input.replace(/\s+/g, '')}2024 #${input.replace(/\s+/g, '')}Journey #SmallCreator #CreatorEconomy #ContentMarketing #GrowYourAudience #NewCreator

📊 PLATFORM-SPECIFIC:

For Instagram (30 hashtags):
#${input.replace(/\s+/g, '')} #ContentCreator #InstagramGrowth #InstaDaily #ReelsViral #ExploreMore #InstaTips #IGCreator #InstagramStrategy #ContentIdeas #CreatorLife #DigitalMarketing #SocialMedia #Instagram #Trending #ViralReels #GrowthMindset #OnlineBusiness #Entrepreneur #Success #Motivation #InstaGood #InstaDailyPost #ReelItFeelIt #ViralContent #ContentMarketing #InstagramTips #Hustle #CreateContent #VideoContent

For YouTube (Tags):
${input}, ${input} tutorial, ${input} guide, ${input} tips 2024, how to ${input}, ${input} for beginners, best ${input} strategy, ${input} explained

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
💡 Best practice: Mix high, medium & niche hashtags
📊 Optimal count: Instagram 20-30 | TikTok 3-5 | Twitter 2-3`,

  'thumbnail-prompt': (input) => `🖼️ THUMBNAIL PROMPTS – "${input}"
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

MIDJOURNEY / DALL-E PROMPTS:

PROMPT 1 – Reaction Style:
"YouTube thumbnail, shocked face of a young person with wide eyes and open mouth, bold orange text overlay '${input}', bright yellow background, high contrast, professional studio lighting, 4K, ultra realistic, trending YouTube style --ar 16:9"

PROMPT 2 – Split Screen Style:
"YouTube thumbnail split screen, left side showing 'BEFORE' with dark sad atmosphere, right side 'AFTER' with bright happy successful person, bold white text '${input}', dramatic lighting contrast, high quality --ar 16:9"

PROMPT 3 – Minimal Bold Style:
"Minimalist YouTube thumbnail, dark blue gradient background, glowing neon text '${input}', bright accent arrow pointing right, modern clean design, professional, high contrast --ar 16:9"

PROMPT 4 – Face + Text Overlay:
"YouTube thumbnail, confident person pointing at bold text '${input}', bright red and yellow color scheme, dramatic shadows, clickbait style, ultra sharp, professional quality --ar 16:9"

PROMPT 5 – Product/Object Focus:
"YouTube thumbnail, dramatic cinematic lighting on subject related to '${input}', golden hour lighting, shallow depth of field, viral social media style, vibrant colors --ar 16:9"

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
🎨 Color Psychology:
• Red/Orange → Urgency & excitement
• Blue/Purple → Trust & authority  
• Yellow/Green → Positivity & growth
💡 Tools: Midjourney, DALL-E 3, Canva AI, Adobe Firefly`,

  'product-ad-copy': (input) => `📢 AD COPY – "${input}"
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

FACEBOOK / INSTAGRAM AD:

HEADLINE:
"Finally – ${input} That Actually Works 🔥"

PRIMARY TEXT:
Tired of wasting money on products that disappoint?

Introducing ${input} – the solution thousands are raving about.

Here's what makes it different:
✅ [Benefit 1 – Speed/Quality]
✅ [Benefit 2 – Value/Price]
✅ [Benefit 3 – Unique feature]

Join 10,000+ happy customers who made the switch.

⚡ LIMITED TIME: Get 30% off + FREE shipping today only.
🔒 30-day money-back guarantee. Zero risk.

👇 Click "Shop Now" before this offer expires!

━━━━━━━━━━━━━━━━━━━

GOOGLE AD COPY:

Headline 1: Buy ${input} – Best Price Online
Headline 2: 30-Day Money Back Guarantee
Headline 3: Free Shipping | 5-Star Rated
Description: Get the best ${input} with fast delivery. Trusted by 10,000+ customers. Shop now & save 30% today only.

━━━━━━━━━━━━━━━━━━━

EMAIL SUBJECT LINES:
• "⚡ Your ${input} is waiting... (30% off ends tonight)"
• "Why everyone's talking about ${input} right now"
• "This changes everything about ${input}"
• "[FLASH SALE] ${input} – 30% off for next 24 hours"

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
🎯 Conversion tips: Always include social proof + urgency + guarantee`,

  'blog-post': (input) => `📝 BLOG POST – "${input}"
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

TITLE: The Ultimate Guide to ${input} in 2024: Everything You Need to Know

META DESCRIPTION: Discover the complete, up-to-date guide to ${input}. Learn proven strategies, expert tips, and step-by-step methods that actually work. Start reading now.

━━━━━━━━━━━━━━━━

# The Ultimate Guide to ${input} in 2024

If you've been searching for a comprehensive, no-fluff guide to **${input}**, you've come to the right place.

In this post, I'll walk you through everything from the basics to advanced strategies – based on real experience and proven results.

## Why ${input} Matters More Than Ever

In today's fast-paced world, understanding **${input}** isn't optional – it's essential. Here's why:

- The industry has grown 340% in the last 3 years
- Early adopters are seeing 10x results compared to latecomers
- Most people are still doing it wrong (which is your opportunity)

## Getting Started with ${input}

### Step 1: Understand the Fundamentals

Before diving into tactics, you need to understand the core principles of ${input}...

### Step 2: Set Up Your Foundation

The biggest mistake beginners make with ${input} is skipping this step. Here's what you need...

### Step 3: Execute with Consistency

Consistency is the #1 differentiator between those who succeed with ${input} and those who don't...

## Common Mistakes to Avoid

1. **Mistake #1:** Starting without a clear strategy
2. **Mistake #2:** Focusing on vanity metrics instead of results
3. **Mistake #3:** Giving up too early before seeing results

## Advanced ${input} Strategies for 2024

Once you've mastered the basics, these advanced tactics will help you scale...

## Conclusion

Mastering **${input}** is a journey, not a destination. Start with the fundamentals, stay consistent, and iterate based on results.

**Your next step:** Pick ONE strategy from this guide and implement it today.

*Found this helpful? Share it with someone who needs it!*

---
**Tags:** ${input}, ${input} guide, ${input} tips, ${input} 2024, how to ${input}
**Word count:** ~1,200 words | **Reading time:** 6 minutes`,

  'instagram-caption': (input) => `📸 INSTAGRAM CAPTIONS – "${input}"
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

CAPTION 1 – Story + Value:
${input} changed everything for me. 

Here's what nobody tells you:

→ It's not about perfection
→ It's not about being the best
→ It's about showing up, every single day

3 years ago, I was exactly where you might be right now. Lost. Uncertain. Doubting myself.

Then I committed to ${input} for just 30 days.

The results surprised even me. 📈

Save this post for when you need a reminder that consistency beats talent. Every. Single. Time.

Double tap if this resonates with you ❤️

#${input.replace(/\s+/g, '')} #Growth #Consistency #Mindset #CreatorLife

━━━━━━━━━━━━━━━━━━

CAPTION 2 – Engagement Bait:
Quick question... 👇

Are you ACTUALLY doing ${input} the right way?

Most people aren't. And it's costing them time, energy, and results.

Comment "YES" if you want me to share my exact process that helped me grow from 0 to 50K in 6 months. 🚀

━━━━━━━━━━━━━━━━━━

CAPTION 3 – Short & Punchy:
${input} ≠ hard.

${input} = consistent.

That's literally the whole secret. 🎯

Drop a 🔥 below if you needed this reminder today.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
💡 Best posting times: 6-9 AM, 12-2 PM, 7-9 PM (local time)
📊 Optimal caption length: 150-300 characters for feed posts`,

  'content-calendar': (input) => `📅 30-DAY CONTENT CALENDAR – "${input}"
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

WEEK 1: FOUNDATION & AWARENESS

Day 1 (Mon) – YouTube Long-form:
"The Complete Beginner's Guide to ${input}" (15-20 min tutorial)

Day 2 (Tue) – Instagram Reel:
"5 ${input} mistakes I wish I knew earlier" (60-second reel)

Day 3 (Wed) – Blog Post:
"Why ${input} is the #1 skill to learn in 2024"

Day 4 (Thu) – Twitter/X Thread:
"10 ${input} tips that nobody talks about 🧵"

Day 5 (Fri) – YouTube Short:
"Day 1 of ${input} challenge – what happened?" 

Day 6 (Sat) – Instagram Carousel:
"${input} explained in 10 slides" (educational carousel)

Day 7 (Sun) – Rest / Batch content

━━━━━━━━━━━━━━━━━━

WEEK 2: ENGAGEMENT & VALUE

Day 8 – YouTube: Case Study video
Day 9 – Instagram: Behind-the-scenes story
Day 10 – LinkedIn: Industry insights post
Day 11 – YouTube Short: Quick tip
Day 12 – Blog: "Top 10 tools for ${input}"
Day 13 – Instagram Reel: Transformation content
Day 14 – Twitter: Weekly recap thread

━━━━━━━━━━━━━━━━━━

WEEK 3: CONVERSION & OFFERS

Day 15 – YouTube: "My ${input} results after 90 days"
Day 16 – Instagram: Product/offer teaser
Day 17 – Email blast: Special offer
Day 18 – YouTube Short: FAQ video
Day 19 – Blog: Comparison post
Day 20 – Instagram: User testimonials
Day 21 – Twitter/X: Engage with community

━━━━━━━━━━━━━━━━━━

WEEK 4: SCALE & REPURPOSE

Day 22-28: Repurpose top content from weeks 1-3
Create platform-specific versions of your best posts

Day 29 – Monthly recap video/post
Day 30 – Next month planning + audience poll

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
🎯 Platforms: ${input}
📊 Posting frequency: 6x/week (sustainable)
⚡ Batch filming: Sunday = record week's content
🔄 Repurposing rule: 1 long-form → 5+ short pieces`,
};

// ─── AI Provider Functions ───────────────────────────────────────────────────

/**
 * Call OpenAI API
 */
async function callOpenAI(prompt: string, apiKey: string): Promise<string> {
  const response = await fetch('https://api.openai.com/v1/chat/completions', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${apiKey}`,
    },
    body: JSON.stringify({
      model: 'gpt-4o-mini',
      messages: [{ role: 'user', content: prompt }],
      max_tokens: 1500,
      temperature: 0.8,
    }),
  });
  const data = await response.json();
  if (data.error) throw new Error(data.error.message);
  return data.choices[0].message.content;
}

/**
 * Call Anthropic Claude API
 */
async function callClaude(prompt: string, apiKey: string): Promise<string> {
  const response = await fetch('https://api.anthropic.com/v1/messages', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'x-api-key': apiKey,
      'anthropic-version': '2023-06-01',
    },
    body: JSON.stringify({
      model: 'claude-3-haiku-20240307',
      max_tokens: 1500,
      messages: [{ role: 'user', content: prompt }],
    }),
  });
  const data = await response.json();
  if (data.error) throw new Error(data.error.message);
  return data.content[0].text;
}

/**
 * Call DeepSeek API
 */
async function callDeepSeek(prompt: string, apiKey: string): Promise<string> {
  const response = await fetch('https://api.deepseek.com/v1/chat/completions', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${apiKey}`,
    },
    body: JSON.stringify({
      model: 'deepseek-chat',
      messages: [{ role: 'user', content: prompt }],
      max_tokens: 1500,
    }),
  });
  const data = await response.json();
  if (data.error) throw new Error(data.error.message);
  return data.choices[0].message.content;
}

/**
 * Build the system prompt for each tool
 */
function buildPrompt(toolId: ToolId, input: string, tone: string, length: string, language: string): string {
  const lengthMap = { short: '150-300 words', medium: '300-600 words', long: '600-1000 words' };
  const baseInstructions = `You are an expert content creator AI assistant. 
Language: ${language}
Tone: ${tone}
Output length: ${lengthMap[length as keyof typeof lengthMap]}
Format your response clearly with sections, emojis where appropriate, and actionable content.`;

  const toolPrompts: Record<ToolId, string> = {
    'shorts-script': `${baseInstructions}\n\nCreate a viral YouTube Shorts/Instagram Reels script for: "${input}"\nInclude: Hook (0-5s), Body with 3 key points (5-50s), and CTA (50-60s). Add timing markers.`,
    'viral-hook': `${baseInstructions}\n\nGenerate 7 different viral hooks for content about: "${input}"\nEach hook should use a different psychological trigger (curiosity, fear, social proof, etc.)`,
    'youtube-title': `${baseInstructions}\n\nGenerate 10 high-CTR YouTube video titles for: "${input}"\nUse power words, numbers, and emotional triggers. Include analysis of each title's strength.`,
    'seo-description': `${baseInstructions}\n\nWrite an SEO-optimized description for content about: "${input}"\nInclude meta description (155 chars), YouTube description with timestamps placeholder, and keyword analysis.`,
    'hashtag-generator': `${baseInstructions}\n\nGenerate a complete hashtag strategy for: "${input}"\nOrganize by reach (high/medium/niche) and by platform (Instagram/YouTube/Twitter/TikTok).`,
    'thumbnail-prompt': `${baseInstructions}\n\nCreate 5 detailed AI image generation prompts for YouTube thumbnails about: "${input}"\nInclude style descriptions, color schemes, and composition details.`,
    'product-ad-copy': `${baseInstructions}\n\nWrite high-converting ad copy for: "${input}"\nInclude Facebook/Instagram ad, Google Ad headlines, and email subject lines. Add conversion tips.`,
    'blog-post': `${baseInstructions}\n\nWrite a complete SEO blog post about: "${input}"\nInclude title, meta description, H1/H2/H3 headings, introduction, body with key sections, and conclusion. Make it engaging and informative.`,
    'instagram-caption': `${baseInstructions}\n\nCreate 3 different Instagram captions for: "${input}"\nEach should have different style: Story-based, Engagement-focused, and Short & punchy. Include relevant hashtags.`,
    'content-calendar': `${baseInstructions}\n\nCreate a detailed 30-day content calendar for: "${input}"\nBreak it into 4 weeks with daily content ideas, platforms, and content types. Include batch creation tips.`,
  };

  return toolPrompts[toolId];
}

// ─── Main Generate Function ───────────────────────────────────────────────────

/**
 * Generate AI content based on the selected tool and input
 * Falls back to mock responses if no API key is configured
 */
export async function generateContent(
  request: GenerateRequest,
  settings: AppSettings
): Promise<GenerateResponse> {
  const { toolId, input } = request;
  const { aiProvider, apiKey, tone, outputLength, language } = settings;

  // Simulate network delay for mock
  if (aiProvider === 'mock' || !apiKey) {
    await new Promise(resolve => setTimeout(resolve, 2000 + Math.random() * 1000));
    const mockFn = MOCK_RESPONSES[toolId];
    return {
      output: mockFn ? mockFn(input) : `Generated content for "${input}" using ${toolId}`,
      model: 'mock-ai-v1',
      tokensUsed: Math.floor(Math.random() * 500) + 200,
    };
  }

  // Build the prompt
  const prompt = buildPrompt(toolId, input, tone, outputLength, language);

  try {
    let output = '';

    switch (aiProvider) {
      case 'openai':
        output = await callOpenAI(prompt, apiKey);
        break;
      case 'claude':
        output = await callClaude(prompt, apiKey);
        break;
      case 'deepseek':
        output = await callDeepSeek(prompt, apiKey);
        break;
      case 'nvidia':
        // NVIDIA NIM uses OpenAI-compatible API
        output = await callOpenAI(prompt, apiKey);
        break;
      default:
        // Fallback to mock
        await new Promise(resolve => setTimeout(resolve, 1500));
        output = MOCK_RESPONSES[toolId](input);
    }

    return { output, model: aiProvider, tokensUsed: Math.floor(prompt.length / 4) };
  } catch (error) {
    console.error('AI API Error:', error);
    // Graceful fallback to mock on error
    await new Promise(resolve => setTimeout(resolve, 500));
    return {
      output: MOCK_RESPONSES[toolId](input) + '\n\n⚠️ [Note: Using mock response. Check your API key in Settings.]',
      model: 'mock-fallback',
    };
  }
}
