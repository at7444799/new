// =========================================
// CreatorOS AI – Home Page
// Landing page with hero, features, stats, testimonials, CTA
// =========================================

import { Link } from 'react-router-dom';
import {
  Zap, ArrowRight, Star, Users, TrendingUp, Shield,
  Film, Hash, Search, FileText, Calendar, Megaphone,
  CheckCircle, Play, ChevronRight
} from 'lucide-react';
import Navbar from '../components/layout/Navbar';
import Button from '../components/ui/Button';
import GlassCard from '../components/ui/GlassCard';
import Badge from '../components/ui/Badge';
import AnimatedCounter from '../components/ui/AnimatedCounter';
import { TOOLS } from '../data/tools';

// Stats data
const STATS = [
  { value: 50000, suffix: '+', label: 'Active Creators', icon: Users },
  { value: 2000000, suffix: '+', label: 'Content Generated', icon: FileText },
  { value: 10, suffix: 'x', label: 'Faster Creation', icon: TrendingUp },
  { value: 99, suffix: '.9%', label: 'Uptime SLA', icon: Shield },
];

// Testimonials
const TESTIMONIALS = [
  {
    name: 'Rahul Sharma',
    role: 'YouTuber · 500K subscribers',
    avatar: 'R',
    rating: 5,
    text: 'CreatorOS AI completely transformed my workflow. I used to spend 4 hours writing scripts. Now it takes 5 minutes. My views have 3x\'d since I started using it.',
    gradient: 'from-indigo-500 to-violet-600',
  },
  {
    name: 'Priya Mehta',
    role: 'Instagram Creator · 200K followers',
    avatar: 'P',
    rating: 5,
    text: 'The viral hook generator is insane. My reels went from 10K to 500K+ views after I started using AI-generated hooks. This tool pays for itself 100x over.',
    gradient: 'from-pink-500 to-rose-600',
  },
  {
    name: 'Arjun Kapoor',
    role: 'Small Business Owner',
    avatar: 'A',
    rating: 5,
    text: 'The Product Ad Copy generator helped me cut my ad writing time by 90%. My ROAS improved from 2x to 6x within 2 weeks. Absolutely game-changing.',
    gradient: 'from-emerald-500 to-teal-600',
  },
];

// Feature highlights
const FEATURES_HIGHLIGHTS = [
  {
    icon: Film,
    title: 'Script in Seconds',
    desc: 'Generate full 60-second Shorts scripts with hooks, body, and CTAs instantly.',
    color: 'text-red-400',
    bg: 'bg-red-500/10',
  },
  {
    icon: TrendingUp,
    title: 'Viral Content Formula',
    desc: 'AI trained on millions of viral posts to maximize your reach and engagement.',
    color: 'text-yellow-400',
    bg: 'bg-yellow-500/10',
  },
  {
    icon: Search,
    title: 'SEO Optimized Output',
    desc: 'Every piece of content is optimized for search engines and platform algorithms.',
    color: 'text-emerald-400',
    bg: 'bg-emerald-500/10',
  },
  {
    icon: Hash,
    title: 'Smart Hashtag Strategy',
    desc: 'Platform-specific hashtag bundles organized by reach – high, medium, niche.',
    color: 'text-violet-400',
    bg: 'bg-violet-500/10',
  },
  {
    icon: Calendar,
    title: '30-Day Content Calendar',
    desc: 'Never run out of content ideas. Get a full month planned in seconds.',
    color: 'text-teal-400',
    bg: 'bg-teal-500/10',
  },
  {
    icon: Megaphone,
    title: 'Convert Selling Copy',
    desc: 'Facebook, Instagram & Google Ads copy that converts visitors to buyers.',
    color: 'text-orange-400',
    bg: 'bg-orange-500/10',
  },
];

export default function Home() {
  return (
    <div className="min-h-screen bg-slate-950 text-slate-100">
      <Navbar />

      {/* ─── Hero Section ─────────────────────────────── */}
      <section className="relative min-h-screen flex items-center pt-16 overflow-hidden">
        {/* Background */}
        <div className="absolute inset-0 bg-gradient-hero grid-pattern" />

        {/* Animated Orbs */}
        <div className="absolute top-1/4 left-1/4 w-96 h-96 orb orb-indigo opacity-30" />
        <div className="absolute bottom-1/4 right-1/4 w-80 h-80 orb orb-blue opacity-20" style={{ animationDelay: '-3s' }} />
        <div className="absolute top-1/2 right-1/3 w-64 h-64 orb orb-purple opacity-25" style={{ animationDelay: '-5s' }} />

        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
          <div className="text-center max-w-4xl mx-auto">
            {/* Badge */}
            <div className="inline-flex items-center gap-2 mb-8">
              <Badge variant="purple" dot>New · 10 AI Tools in One Platform</Badge>
            </div>

            {/* Headline */}
            <h1 className="text-4xl sm:text-6xl lg:text-7xl font-extrabold leading-tight mb-6">
              <span className="text-white">Create Viral Content</span>
              <br />
              <span className="gradient-text">10x Faster with AI</span>
            </h1>

            {/* Subheadline */}
            <p className="text-lg sm:text-xl text-slate-400 mb-10 max-w-2xl mx-auto leading-relaxed">
              The all-in-one AI platform for YouTubers, Instagram creators, small businesses & product sellers.
              Generate scripts, hooks, titles, captions, and more in seconds.
            </p>

            {/* CTA Buttons */}
            <div className="flex flex-col sm:flex-row gap-4 justify-center mb-16">
              <Link to="/register">
                <Button size="xl" icon={<Zap className="w-5 h-5 fill-white" />} iconRight={<ArrowRight className="w-5 h-5" />}>
                  Start Creating for Free
                </Button>
              </Link>
              <Link to="/features">
                <Button size="xl" variant="secondary" icon={<Play className="w-5 h-5" />}>
                  See All Features
                </Button>
              </Link>
            </div>

            {/* Social Proof */}
            <div className="flex flex-col sm:flex-row items-center justify-center gap-6 text-sm text-slate-500">
              <div className="flex items-center gap-2">
                <div className="flex -space-x-2">
                  {['R', 'P', 'A', 'K', 'S'].map((l, i) => (
                    <div key={i} className="w-8 h-8 rounded-full border-2 border-slate-950 bg-gradient-to-br from-indigo-500 to-violet-600 flex items-center justify-center text-xs font-bold text-white">
                      {l}
                    </div>
                  ))}
                </div>
                <span>50,000+ creators</span>
              </div>
              <div className="hidden sm:block w-1 h-1 rounded-full bg-slate-700" />
              <div className="flex items-center gap-1">
                {[...Array(5)].map((_, i) => (
                  <Star key={i} className="w-4 h-4 text-yellow-400 fill-yellow-400" />
                ))}
                <span className="ml-1">4.9/5 rating</span>
              </div>
              <div className="hidden sm:block w-1 h-1 rounded-full bg-slate-700" />
              <div className="flex items-center gap-1">
                <CheckCircle className="w-4 h-4 text-emerald-400" />
                <span>No credit card required</span>
              </div>
            </div>
          </div>

          {/* Hero Image / Dashboard Preview */}
          <div className="mt-20 relative max-w-5xl mx-auto">
            <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-transparent to-transparent z-10 pointer-events-none" />
            <div className="relative rounded-2xl overflow-hidden border border-indigo-500/20 shadow-2xl shadow-indigo-500/10">
              {/* Mock Dashboard Preview */}
              <div className="bg-slate-900 p-1">
                {/* Browser bar */}
                <div className="flex items-center gap-2 px-3 py-2 border-b border-slate-800">
                  <div className="flex gap-1.5">
                    <div className="w-3 h-3 rounded-full bg-red-500/60" />
                    <div className="w-3 h-3 rounded-full bg-yellow-500/60" />
                    <div className="w-3 h-3 rounded-full bg-emerald-500/60" />
                  </div>
                  <div className="flex-1 flex justify-center">
                    <div className="px-4 py-1 rounded-md bg-slate-800 text-xs text-slate-500 font-mono">
                      app.creatorosai.com/dashboard
                    </div>
                  </div>
                </div>

                {/* Dashboard content preview */}
                <div className="grid grid-cols-12 gap-4 p-4">
                  {/* Sidebar */}
                  <div className="col-span-2 space-y-1.5">
                    {['Dashboard', 'Viral Hook', 'YT Title', 'SEO Desc', 'Hashtags', 'Ad Copy'].map((item, i) => (
                      <div key={i} className={`px-2 py-1.5 rounded-lg text-xs ${i === 1 ? 'bg-indigo-500/20 text-indigo-300 border border-indigo-500/30' : 'text-slate-600'}`}>
                        {item}
                      </div>
                    ))}
                  </div>

                  {/* Main area */}
                  <div className="col-span-10 space-y-3">
                    <div className="rounded-lg bg-slate-800/60 p-3">
                      <div className="text-xs text-slate-400 mb-2">Viral Hook Generator</div>
                      <div className="flex gap-2">
                        <div className="flex-1 rounded bg-slate-700/50 px-3 py-2 text-xs text-slate-500">How I grew to 100K subscribers...</div>
                        <div className="px-3 py-2 rounded bg-gradient-to-r from-indigo-600 to-violet-600 text-xs text-white font-medium">Generate ✨</div>
                      </div>
                    </div>

                    <div className="rounded-lg bg-slate-800/40 p-3 border border-indigo-500/20">
                      <div className="text-xs text-emerald-400 mb-2">✅ Generated Output</div>
                      <div className="space-y-1.5">
                        {[
                          '"I wasted 3 years on YouTube before I discovered this..."',
                          '"What if 90% of creators are doing this WRONG?"',
                          '"The algorithm secret big channels don\'t want you to know"',
                        ].map((hook, i) => (
                          <div key={i} className="text-xs text-slate-400 bg-slate-900/50 rounded px-2 py-1.5 border border-slate-700/50">
                            {hook}
                          </div>
                        ))}
                      </div>
                    </div>

                    <div className="grid grid-cols-3 gap-2">
                      {['Copy All', 'Save', 'Regenerate'].map((btn, i) => (
                        <div key={i} className={`py-1.5 rounded text-xs text-center font-medium ${i === 0 ? 'bg-indigo-500/20 text-indigo-300 border border-indigo-500/30' : 'bg-slate-800 text-slate-500'}`}>
                          {btn}
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* ─── Stats Section ─────────────────────────────── */}
      <section className="py-20 border-y border-slate-800/50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-8">
            {STATS.map((stat) => (
              <div key={stat.label} className="text-center">
                <div className="stat-number gradient-text mb-2">
                  <AnimatedCounter target={stat.value} suffix={stat.suffix} />
                </div>
                <div className="text-slate-400 text-sm">{stat.label}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ─── Tools Grid ─────────────────────────────── */}
      <section className="py-24 bg-gradient-section">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <Badge variant="blue" className="mb-4">10 Powerful AI Tools</Badge>
            <h2 className="text-3xl sm:text-5xl font-bold text-white mb-4">
              Everything You Need to{' '}
              <span className="gradient-text">Go Viral</span>
            </h2>
            <p className="text-slate-400 text-lg max-w-2xl mx-auto">
              From scripting to scheduling, our AI handles every aspect of content creation.
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
            {TOOLS.map(tool => (
              <Link to={`/tool/${tool.id}`} key={tool.id}>
                <GlassCard hover padding="md" className="h-full group">
                  <div className="flex items-start gap-3 mb-3">
                    <div
                      className="w-10 h-10 rounded-xl flex items-center justify-center text-xl flex-shrink-0"
                      style={{ background: tool.bgColor }}
                    >
                      {tool.icon}
                    </div>
                    <div className="flex-1 min-w-0">
                      {tool.badge && (
                        <Badge variant={tool.badge === 'Hot' ? 'red' : tool.badge === 'New' ? 'green' : 'purple'} className="mb-1 text-xs py-0">
                          {tool.badge}
                        </Badge>
                      )}
                      <h3 className="font-semibold text-white text-sm leading-tight">{tool.name}</h3>
                    </div>
                  </div>
                  <p className="text-xs text-slate-400 leading-relaxed">{tool.description}</p>
                  <div className="mt-3 flex items-center gap-1 text-xs font-medium opacity-0 group-hover:opacity-100 transition-opacity" style={{ color: tool.color }}>
                    Try it now <ChevronRight className="w-3 h-3" />
                  </div>
                </GlassCard>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* ─── Features Highlight ─────────────────────────────── */}
      <section className="py-24">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <Badge variant="purple" className="mb-4">Why CreatorOS AI?</Badge>
            <h2 className="text-3xl sm:text-5xl font-bold text-white mb-4">
              Built for <span className="gradient-text">Real Creators</span>
            </h2>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {FEATURES_HIGHLIGHTS.map(feature => (
              <GlassCard key={feature.title} hover padding="lg">
                <div className={`w-12 h-12 rounded-xl ${feature.bg} flex items-center justify-center mb-4`}>
                  <feature.icon className={`w-6 h-6 ${feature.color}`} />
                </div>
                <h3 className="text-lg font-bold text-white mb-2">{feature.title}</h3>
                <p className="text-slate-400 text-sm leading-relaxed">{feature.desc}</p>
              </GlassCard>
            ))}
          </div>
        </div>
      </section>

      {/* ─── Testimonials ─────────────────────────────── */}
      <section className="py-24 bg-gradient-section">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <Badge variant="green" className="mb-4">Loved by Creators</Badge>
            <h2 className="text-3xl sm:text-5xl font-bold text-white mb-4">
              What Creators Are <span className="gradient-text">Saying</span>
            </h2>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {TESTIMONIALS.map(t => (
              <GlassCard key={t.name} padding="lg" glow>
                <div className="flex items-center gap-3 mb-4">
                  <div className={`w-11 h-11 rounded-xl bg-gradient-to-br ${t.gradient} flex items-center justify-center text-lg font-bold text-white`}>
                    {t.avatar}
                  </div>
                  <div>
                    <p className="font-semibold text-white text-sm">{t.name}</p>
                    <p className="text-xs text-slate-400">{t.role}</p>
                  </div>
                </div>
                <div className="flex gap-1 mb-3">
                  {[...Array(t.rating)].map((_, i) => (
                    <Star key={i} className="w-3.5 h-3.5 text-yellow-400 fill-yellow-400" />
                  ))}
                </div>
                <p className="text-slate-300 text-sm leading-relaxed">"{t.text}"</p>
              </GlassCard>
            ))}
          </div>
        </div>
      </section>

      {/* ─── CTA Section ─────────────────────────────── */}
      <section className="py-24">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <div className="relative">
            {/* Glow */}
            <div className="absolute inset-0 flex items-center justify-center">
              <div className="w-96 h-48 bg-indigo-500/20 blur-3xl rounded-full" />
            </div>

            <div className="relative">
              <Badge variant="purple" dot className="mb-6">Start for Free · No Credit Card</Badge>
              <h2 className="text-4xl sm:text-6xl font-extrabold text-white mb-6">
                Start Creating Viral Content
                <span className="gradient-text"> Today</span>
              </h2>
              <p className="text-slate-400 text-lg mb-10">
                Join 50,000+ creators who are already saving hours every week.
                Get 10 free generations – no credit card required.
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <Link to="/register">
                  <Button size="xl" icon={<Zap className="w-5 h-5 fill-white" />}>
                    Get Started Free
                  </Button>
                </Link>
                <Link to="/pricing">
                  <Button size="xl" variant="secondary">
                    View Pricing Plans
                  </Button>
                </Link>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* ─── Footer ─────────────────────────────── */}
      <footer className="border-t border-slate-800/50 py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8 mb-12">
            <div className="col-span-2 md:col-span-1">
              <div className="flex items-center gap-2 mb-4">
                <div className="w-7 h-7 rounded-lg bg-gradient-to-br from-indigo-500 to-violet-600 flex items-center justify-center">
                  <Zap className="w-3.5 h-3.5 text-white fill-white" />
                </div>
                <span className="font-bold text-white">CreatorOS AI</span>
              </div>
              <p className="text-sm text-slate-500 leading-relaxed">
                The all-in-one AI content platform for modern creators.
              </p>
            </div>

            {[
              { title: 'Product', links: ['Features', 'Pricing', 'Dashboard', 'API'] },
              { title: 'Tools', links: ['Shorts Script', 'Viral Hook', 'YT Title', 'Hashtags'] },
              { title: 'Company', links: ['About', 'Blog', 'Privacy', 'Terms'] },
            ].map(col => (
              <div key={col.title}>
                <h4 className="text-sm font-semibold text-white mb-4">{col.title}</h4>
                <ul className="space-y-2">
                  {col.links.map(link => (
                    <li key={link}>
                      <span className="text-sm text-slate-500 hover:text-slate-300 cursor-pointer transition-colors">{link}</span>
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>

          <div className="border-t border-slate-800/50 pt-8 flex flex-col sm:flex-row justify-between items-center gap-4">
            <p className="text-sm text-slate-600">© 2024 CreatorOS AI. All rights reserved.</p>
            <div className="flex items-center gap-4 text-sm text-slate-600">
              <span className="hover:text-slate-400 cursor-pointer">Privacy Policy</span>
              <span className="hover:text-slate-400 cursor-pointer">Terms of Service</span>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
