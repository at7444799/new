// =========================================
// CreatorOS AI – Dashboard Page
// Main user dashboard with stats and quick access
// =========================================

import { Link } from 'react-router-dom';
import { ArrowRight, TrendingUp, Clock, Bookmark, Zap, ChevronRight } from 'lucide-react';
import DashboardLayout from '../components/layout/DashboardLayout';
import GlassCard from '../components/ui/GlassCard';
import Badge from '../components/ui/Badge';
import Button from '../components/ui/Button';
import { useApp } from '../context/AppContext';
import { TOOLS } from '../data/tools';
import { formatDistanceToNow } from 'date-fns';

export default function Dashboard() {
  const { user, history } = useApp();

  const savedCount = history.filter(h => h.saved).length;
  const recentHistory = history.slice(0, 5);

  const stats = [
    {
      label: 'Generations Used',
      value: user?.generationsUsed || 0,
      total: user?.generationsLimit || 10,
      icon: Zap,
      color: 'text-indigo-400',
      bg: 'bg-indigo-500/10',
      showBar: true,
    },
    {
      label: 'Total Generated',
      value: history.length,
      icon: TrendingUp,
      color: 'text-emerald-400',
      bg: 'bg-emerald-500/10',
      showBar: false,
    },
    {
      label: 'Saved Items',
      value: savedCount,
      icon: Bookmark,
      color: 'text-violet-400',
      bg: 'bg-violet-500/10',
      showBar: false,
    },
    {
      label: 'Remaining',
      value: (user?.generationsLimit || 10) - (user?.generationsUsed || 0),
      icon: Clock,
      color: 'text-cyan-400',
      bg: 'bg-cyan-500/10',
      showBar: false,
    },
  ];

  return (
    <DashboardLayout title="Dashboard" subtitle={`Welcome back, ${user?.name?.split(' ')[0] || 'Creator'}! 👋`}>
      <div className="space-y-8 fade-in">

        {/* Plan Banner */}
        {user?.plan === 'free' && (
          <div className="relative overflow-hidden rounded-2xl p-5 bg-gradient-to-r from-indigo-500/10 to-violet-500/5 border border-indigo-500/30">
            <div className="absolute right-0 top-0 bottom-0 w-32 bg-gradient-to-l from-violet-500/10 to-transparent" />
            <div className="flex items-center justify-between gap-4">
              <div>
                <p className="font-semibold text-white mb-1">You're on the Free Plan</p>
                <p className="text-sm text-slate-400">
                  {user.generationsLimit - user.generationsUsed} generations remaining this month.
                  Upgrade to unlock unlimited tools.
                </p>
              </div>
              <Link to="/pricing" className="flex-shrink-0">
                <Button size="sm" icon={<Zap className="w-4 h-4" />}>Upgrade Now</Button>
              </Link>
            </div>
          </div>
        )}

        {/* Stats Grid */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          {stats.map(stat => (
            <GlassCard key={stat.label} padding="md">
              <div className={`w-10 h-10 ${stat.bg} rounded-xl flex items-center justify-center mb-3`}>
                <stat.icon className={`w-5 h-5 ${stat.color}`} />
              </div>
              <div className="text-2xl font-bold text-white mb-1">{stat.value}</div>
              <div className="text-xs text-slate-400">{stat.label}</div>
              {stat.showBar && stat.total && (
                <div className="mt-2 progress-bar h-1.5">
                  <div
                    className="progress-fill h-full"
                    style={{ width: `${Math.min((stat.value / stat.total) * 100, 100)}%` }}
                  />
                </div>
              )}
            </GlassCard>
          ))}
        </div>

        {/* Quick Access Tools */}
        <div>
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-lg font-bold text-white">AI Tools</h2>
            <Link to="/features" className="text-sm text-indigo-400 hover:text-indigo-300 flex items-center gap-1">
              View all <ChevronRight className="w-3.5 h-3.5" />
            </Link>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3">
            {TOOLS.map(tool => (
              <Link to={`/tool/${tool.id}`} key={tool.id}>
                <div className="group glass-card-hover p-4 text-center cursor-pointer">
                  <div
                    className="w-12 h-12 rounded-xl flex items-center justify-center text-2xl mx-auto mb-3"
                    style={{ background: tool.bgColor }}
                  >
                    {tool.icon}
                  </div>
                  <p className="text-xs font-medium text-slate-300 group-hover:text-white transition-colors leading-tight">
                    {tool.name}
                  </p>
                  {tool.badge && (
                    <Badge variant={tool.badge === 'Hot' ? 'red' : tool.badge === 'New' ? 'green' : 'purple'} className="mt-2 text-xs">
                      {tool.badge}
                    </Badge>
                  )}
                </div>
              </Link>
            ))}
          </div>
        </div>

        {/* Quick Generate */}
        <div>
          <h2 className="text-lg font-bold text-white mb-4">Quick Generate</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {TOOLS.slice(0, 4).map(tool => (
              <Link to={`/tool/${tool.id}`} key={tool.id}>
                <GlassCard hover padding="md" className="group">
                  <div className="flex items-center gap-4">
                    <div
                      className="w-12 h-12 rounded-xl flex items-center justify-center text-xl flex-shrink-0"
                      style={{ background: tool.bgColor }}
                    >
                      {tool.icon}
                    </div>
                    <div className="flex-1 min-w-0">
                      <h3 className="font-semibold text-white text-sm">{tool.name}</h3>
                      <p className="text-xs text-slate-400 truncate mt-0.5">{tool.description}</p>
                    </div>
                    <ArrowRight className="w-4 h-4 text-slate-600 group-hover:text-indigo-400 group-hover:translate-x-1 transition-all flex-shrink-0" />
                  </div>
                </GlassCard>
              </Link>
            ))}
          </div>
        </div>

        {/* Recent History */}
        <div>
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-lg font-bold text-white">Recent Activity</h2>
            <Link to="/history" className="text-sm text-indigo-400 hover:text-indigo-300 flex items-center gap-1">
              View all <ChevronRight className="w-3.5 h-3.5" />
            </Link>
          </div>

          {recentHistory.length === 0 ? (
            <GlassCard padding="lg" className="text-center">
              <div className="text-4xl mb-3">🎯</div>
              <p className="text-slate-400 mb-4">No generations yet. Start creating!</p>
              <Link to="/tool/viral-hook">
                <Button size="sm">Try Viral Hook Generator</Button>
              </Link>
            </GlassCard>
          ) : (
            <div className="space-y-3">
              {recentHistory.map(item => (
                <GlassCard key={item.id} padding="sm">
                  <div className="flex items-start gap-3">
                    <div className="flex-shrink-0 mt-0.5">
                      <span className="text-lg">
                        {TOOLS.find(t => t.id === item.toolId)?.icon || '⚡'}
                      </span>
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between gap-2 mb-1">
                        <span className="text-sm font-medium text-white">{item.toolName}</span>
                        <span className="text-xs text-slate-500 flex-shrink-0">
                          {formatDistanceToNow(new Date(item.createdAt), { addSuffix: true })}
                        </span>
                      </div>
                      <p className="text-xs text-slate-400 truncate">{item.input}</p>
                      <p className="text-xs text-slate-500 mt-1 line-clamp-1 font-mono">
                        {item.output.substring(0, 80)}...
                      </p>
                    </div>
                    {item.saved && (
                      <Bookmark className="w-3.5 h-3.5 text-violet-400 flex-shrink-0 mt-1 fill-violet-400" />
                    )}
                  </div>
                </GlassCard>
              ))}
            </div>
          )}
        </div>

        {/* Tips */}
        <GlassCard padding="md" className="bg-gradient-to-r from-indigo-500/5 to-violet-500/5">
          <div className="flex items-start gap-3">
            <div className="text-2xl">💡</div>
            <div>
              <p className="text-sm font-semibold text-white mb-1">Pro Tip</p>
              <p className="text-xs text-slate-400 leading-relaxed">
                Start with the <strong className="text-indigo-300">Viral Hook Generator</strong> to craft your opening, 
                then use the <strong className="text-indigo-300">YouTube Title Generator</strong> to maximize clicks. 
                Combine both for the best results!
              </p>
            </div>
          </div>
        </GlassCard>
      </div>
    </DashboardLayout>
  );
}
