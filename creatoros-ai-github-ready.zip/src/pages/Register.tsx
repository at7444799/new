// =========================================
// CreatorOS AI – Register Page
// =========================================

import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Eye, EyeOff, Zap, Mail, Lock, User, ArrowRight, CheckCircle } from 'lucide-react';
import { useApp } from '../context/AppContext';
import Button from '../components/ui/Button';
import toast from 'react-hot-toast';

const PERKS = [
  '10 free AI generations to start',
  'Access to 5 essential AI tools',
  'Save and copy your outputs',
  'No credit card required',
];

export default function Register() {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [showPass, setShowPass] = useState(false);
  const [agreed, setAgreed] = useState(false);
  const [loading, setLoading] = useState(false);
  const { register } = useApp();
  const navigate = useNavigate();

  const passwordStrength = (): { label: string; color: string; width: string } => {
    if (password.length === 0) return { label: '', color: '', width: '0%' };
    if (password.length < 6) return { label: 'Weak', color: 'bg-red-500', width: '25%' };
    if (password.length < 10) return { label: 'Fair', color: 'bg-yellow-500', width: '50%' };
    if (password.length < 14) return { label: 'Good', color: 'bg-emerald-500', width: '75%' };
    return { label: 'Strong', color: 'bg-indigo-500', width: '100%' };
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name || !email || !password) {
      toast.error('Please fill in all fields');
      return;
    }
    if (password !== confirmPassword) {
      toast.error('Passwords do not match');
      return;
    }
    if (password.length < 6) {
      toast.error('Password must be at least 6 characters');
      return;
    }
    if (!agreed) {
      toast.error('Please accept the terms to continue');
      return;
    }
    setLoading(true);
    try {
      const success = await register(name, email, password);
      if (success) {
        toast.success('Account created! Welcome to CreatorOS AI 🚀');
        navigate('/dashboard');
      }
    } catch {
      toast.error('Something went wrong. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const strength = passwordStrength();

  return (
    <div className="min-h-screen bg-slate-950 flex">
      {/* Left Panel – Branding */}
      <div className="hidden lg:flex lg:w-1/2 relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-hero grid-pattern" />
        <div className="absolute top-1/3 left-1/4 w-80 h-80 orb orb-purple opacity-25" />
        <div className="absolute bottom-1/4 right-1/4 w-72 h-72 orb orb-blue opacity-20" style={{ animationDelay: '-2s' }} />

        <div className="relative flex flex-col justify-center px-16 z-10">
          <Link to="/" className="flex items-center gap-3 mb-16">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-indigo-500 to-violet-600 flex items-center justify-center shadow-lg shadow-indigo-500/30">
              <Zap className="w-5 h-5 text-white fill-white" />
            </div>
            <span className="font-bold text-2xl">
              <span className="gradient-text">Creator</span><span className="text-white">OS AI</span>
            </span>
          </Link>

          <h2 className="text-4xl font-extrabold text-white mb-4 leading-tight">
            Join 50,000+<br />
            <span className="gradient-text">Content Creators 🚀</span>
          </h2>
          <p className="text-slate-400 text-lg mb-10">
            Create your free account and start generating viral content in seconds.
          </p>

          <div className="space-y-4">
            {PERKS.map(perk => (
              <div key={perk} className="flex items-center gap-3">
                <CheckCircle className="w-5 h-5 text-emerald-400 flex-shrink-0" />
                <span className="text-slate-300">{perk}</span>
              </div>
            ))}
          </div>

          <div className="mt-12 p-5 rounded-2xl bg-slate-900/60 border border-indigo-500/20">
            <div className="flex items-center gap-3 mb-2">
              <div className="flex -space-x-2">
                {['S', 'P', 'R'].map((l, i) => (
                  <div key={i} className="w-8 h-8 rounded-full border-2 border-slate-950 bg-gradient-to-br from-indigo-500 to-violet-600 flex items-center justify-center text-xs font-bold text-white">
                    {l}
                  </div>
                ))}
              </div>
              <div className="flex">
                {[...Array(5)].map((_, i) => (
                  <span key={i} className="text-yellow-400 text-sm">★</span>
                ))}
              </div>
            </div>
            <p className="text-sm text-slate-300 italic">
              "I've saved 20+ hours a month on content creation. This tool is a must-have!"
            </p>
            <p className="text-xs text-slate-500 mt-1">— Sneha Patel, Instagram Creator</p>
          </div>
        </div>
      </div>

      {/* Right Panel – Form */}
      <div className="w-full lg:w-1/2 flex flex-col justify-center px-6 sm:px-16 py-12 overflow-y-auto">
        <div className="lg:hidden mb-10">
          <Link to="/" className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-indigo-500 to-violet-600 flex items-center justify-center">
              <Zap className="w-4 h-4 text-white fill-white" />
            </div>
            <span className="font-bold text-xl">
              <span className="gradient-text">Creator</span><span className="text-white">OS AI</span>
            </span>
          </Link>
        </div>

        <div className="max-w-md w-full mx-auto">
          <h1 className="text-3xl font-bold text-white mb-2">Create Account</h1>
          <p className="text-slate-400 mb-8">
            Already have an account?{' '}
            <Link to="/login" className="text-indigo-400 hover:text-indigo-300 font-medium transition-colors">
              Sign in
            </Link>
          </p>

          <form onSubmit={handleSubmit} className="space-y-5">
            {/* Name */}
            <div>
              <label className="block text-sm font-medium text-slate-300 mb-2">Full Name</label>
              <div className="relative">
                <User className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500" />
                <input
                  type="text"
                  value={name}
                  onChange={e => setName(e.target.value)}
                  placeholder="Alex Creator"
                  className="input-dark pl-10"
                  required
                />
              </div>
            </div>

            {/* Email */}
            <div>
              <label className="block text-sm font-medium text-slate-300 mb-2">Email Address</label>
              <div className="relative">
                <Mail className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500" />
                <input
                  type="email"
                  value={email}
                  onChange={e => setEmail(e.target.value)}
                  placeholder="you@example.com"
                  className="input-dark pl-10"
                  required
                />
              </div>
            </div>

            {/* Password */}
            <div>
              <label className="block text-sm font-medium text-slate-300 mb-2">Password</label>
              <div className="relative">
                <Lock className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500" />
                <input
                  type={showPass ? 'text' : 'password'}
                  value={password}
                  onChange={e => setPassword(e.target.value)}
                  placeholder="Min. 6 characters"
                  className="input-dark pl-10 pr-10"
                  required
                />
                <button
                  type="button"
                  onClick={() => setShowPass(!showPass)}
                  className="absolute right-3.5 top-1/2 -translate-y-1/2 text-slate-500 hover:text-slate-300 transition-colors cursor-pointer"
                >
                  {showPass ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
              {password && (
                <div className="mt-2">
                  <div className="flex justify-between text-xs mb-1">
                    <span className="text-slate-500">Password strength</span>
                    <span className={`font-medium ${strength.color.replace('bg-', 'text-')}`}>{strength.label}</span>
                  </div>
                  <div className="h-1.5 bg-slate-800 rounded-full overflow-hidden">
                    <div className={`h-full rounded-full transition-all duration-300 ${strength.color}`} style={{ width: strength.width }} />
                  </div>
                </div>
              )}
            </div>

            {/* Confirm Password */}
            <div>
              <label className="block text-sm font-medium text-slate-300 mb-2">Confirm Password</label>
              <div className="relative">
                <Lock className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500" />
                <input
                  type="password"
                  value={confirmPassword}
                  onChange={e => setConfirmPassword(e.target.value)}
                  placeholder="Repeat password"
                  className={`input-dark pl-10 ${
                    confirmPassword && confirmPassword !== password ? 'border-red-500/50' : ''
                  }`}
                  required
                />
                {confirmPassword && confirmPassword === password && (
                  <CheckCircle className="absolute right-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-emerald-400" />
                )}
              </div>
            </div>

            {/* Terms */}
            <label className="flex items-start gap-3 cursor-pointer">
              <input
                type="checkbox"
                checked={agreed}
                onChange={e => setAgreed(e.target.checked)}
                className="w-4 h-4 mt-0.5 rounded border-slate-700 bg-slate-800 text-indigo-500 focus:ring-indigo-500 focus:ring-offset-0"
              />
              <span className="text-sm text-slate-400">
                I agree to the{' '}
                <span className="text-indigo-400 hover:text-indigo-300 cursor-pointer">Terms of Service</span>
                {' '}and{' '}
                <span className="text-indigo-400 hover:text-indigo-300 cursor-pointer">Privacy Policy</span>
              </span>
            </label>

            <Button type="submit" fullWidth size="lg" loading={loading} iconRight={<ArrowRight className="w-4 h-4" />}>
              Create Free Account
            </Button>
          </form>

          <p className="text-center text-xs text-slate-500 mt-6">
            🔒 Your data is encrypted and secure. We never share your information.
          </p>
        </div>
      </div>
    </div>
  );
}
