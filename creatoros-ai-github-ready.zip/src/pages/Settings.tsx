// =========================================
// CreatorOS AI – Settings Page
// User preferences, AI configuration, account management
// =========================================

import { useState } from 'react';
import { Link } from 'react-router-dom';
import {
  User, Key, Brain, CreditCard, Bell, Shield,
  Save, Eye, EyeOff, ExternalLink, CheckCircle,
  AlertCircle, Crown, Trash2
} from 'lucide-react';
import DashboardLayout from '../components/layout/DashboardLayout';
import GlassCard from '../components/ui/GlassCard';
import Button from '../components/ui/Button';
import Badge from '../components/ui/Badge';
import { useApp } from '../context/AppContext';
import { LANGUAGES, TONES } from '../data/tools';
import toast from 'react-hot-toast';
import { clsx } from 'clsx';

type SettingsTab = 'profile' | 'ai' | 'billing' | 'notifications' | 'security';

const TABS: { id: SettingsTab; label: string; icon: typeof User }[] = [
  { id: 'profile', label: 'Profile', icon: User },
  { id: 'ai', label: 'AI Settings', icon: Brain },
  { id: 'billing', label: 'Billing', icon: CreditCard },
  { id: 'notifications', label: 'Notifications', icon: Bell },
  { id: 'security', label: 'Security', icon: Shield },
];

const AI_PROVIDERS = [
  { id: 'mock', name: 'Mock AI (Demo)', desc: 'No API key needed. Great for testing.', badge: 'Free' },
  { id: 'openai', name: 'OpenAI', desc: 'GPT-4o, GPT-4o-mini. Industry leading AI.', badge: 'Popular' },
  { id: 'claude', name: 'Anthropic Claude', desc: 'Claude 3 Haiku/Sonnet. Excellent for writing.', badge: 'Recommended' },
  { id: 'deepseek', name: 'DeepSeek', desc: 'DeepSeek Chat. Fast and cost-effective.', badge: 'Budget' },
  { id: 'nvidia', name: 'NVIDIA NIM', desc: 'NVIDIA\'s AI API. High performance.', badge: 'Performance' },
];

export default function Settings() {
  const { user, updateUser, settings, updateSettings, clearHistory } = useApp();
  const [activeTab, setActiveTab] = useState<SettingsTab>('profile');

  // Profile state
  const [name, setName] = useState(user?.name || '');
  const [email, setEmail] = useState(user?.email || '');

  // AI settings state
  const [apiKey, setApiKey] = useState(settings.apiKey || '');
  const [showApiKey, setShowApiKey] = useState(false);
  const [selectedProvider, setSelectedProvider] = useState(settings.aiProvider);

  // Notification state
  const [emailNotifs, setEmailNotifs] = useState(true);
  const [weeklyReport, setWeeklyReport] = useState(true);
  const [productUpdates, setProductUpdates] = useState(false);

  const handleSaveProfile = () => {
    updateUser({ name, email });
    toast.success('Profile updated! ✅');
  };

  const handleSaveAI = () => {
    updateSettings({
      aiProvider: selectedProvider as 'mock' | 'openai' | 'claude' | 'deepseek' | 'nvidia',
      apiKey: apiKey || undefined,
    });
    toast.success('AI settings saved! 🤖');
  };

  const handleSaveDefaults = () => {
    toast.success('Default settings saved!');
  };

  const handleClearData = () => {
    if (window.confirm('Clear all your generation history? This cannot be undone.')) {
      clearHistory();
      toast.success('History cleared');
    }
  };

  const getPlanBadgeVariant = () => {
    if (user?.plan === 'agency') return 'yellow';
    if (user?.plan === 'pro') return 'purple';
    if (user?.plan === 'creator') return 'blue';
    return 'gray';
  };

  return (
    <DashboardLayout title="Settings" subtitle="Manage your account and preferences">
      <div className="max-w-5xl mx-auto fade-in">
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">

          {/* Sidebar Tabs */}
          <div className="lg:col-span-1">
            <GlassCard padding="sm">
              <nav className="space-y-1">
                {TABS.map(tab => (
                  <button
                    key={tab.id}
                    onClick={() => setActiveTab(tab.id)}
                    className={clsx(
                      'flex items-center gap-3 w-full px-3 py-2.5 rounded-xl text-sm font-medium transition-all cursor-pointer',
                      activeTab === tab.id
                        ? 'bg-indigo-500/15 text-indigo-300 border border-indigo-500/30'
                        : 'text-slate-400 hover:text-white hover:bg-white/5'
                    )}
                  >
                    <tab.icon className="w-4 h-4" />
                    {tab.label}
                  </button>
                ))}
              </nav>
            </GlassCard>
          </div>

          {/* Content Area */}
          <div className="lg:col-span-3 space-y-6">

            {/* ─── Profile Tab ─── */}
            {activeTab === 'profile' && (
              <>
                <GlassCard padding="lg">
                  <h2 className="text-lg font-bold text-white mb-6 flex items-center gap-2">
                    <User className="w-5 h-5 text-indigo-400" />
                    Profile Information
                  </h2>

                  {/* Avatar */}
                  <div className="flex items-center gap-4 mb-6">
                    <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-indigo-500 to-violet-600 flex items-center justify-center text-2xl font-bold text-white">
                      {user?.name?.charAt(0).toUpperCase() || 'U'}
                    </div>
                    <div>
                      <p className="font-semibold text-white">{user?.name}</p>
                      <p className="text-sm text-slate-400">{user?.email}</p>
                      <div className="flex items-center gap-2 mt-1">
                        <Badge variant={getPlanBadgeVariant()} className="capitalize">{user?.plan} Plan</Badge>
                        <span className="text-xs text-slate-500">
                          {user?.generationsUsed}/{user?.generationsLimit} generations used
                        </span>
                      </div>
                    </div>
                  </div>

                  <div className="space-y-4">
                    <div>
                      <label className="block text-sm font-medium text-slate-300 mb-2">Full Name</label>
                      <input
                        type="text"
                        value={name}
                        onChange={e => setName(e.target.value)}
                        className="input-dark"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-slate-300 mb-2">Email Address</label>
                      <input
                        type="email"
                        value={email}
                        onChange={e => setEmail(e.target.value)}
                        className="input-dark"
                      />
                    </div>
                    <Button icon={<Save className="w-4 h-4" />} onClick={handleSaveProfile}>
                      Save Profile
                    </Button>
                  </div>
                </GlassCard>

                <GlassCard padding="lg">
                  <h2 className="text-lg font-bold text-white mb-4 flex items-center gap-2">
                    <Trash2 className="w-5 h-5 text-red-400" />
                    Danger Zone
                  </h2>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between p-4 rounded-xl bg-red-500/5 border border-red-500/20">
                      <div>
                        <p className="text-sm font-medium text-red-300">Clear Generation History</p>
                        <p className="text-xs text-slate-400">This will permanently delete all your past generations.</p>
                      </div>
                      <Button variant="danger" size="sm" onClick={handleClearData}>Clear History</Button>
                    </div>
                  </div>
                </GlassCard>
              </>
            )}

            {/* ─── AI Settings Tab ─── */}
            {activeTab === 'ai' && (
              <>
                <GlassCard padding="lg">
                  <h2 className="text-lg font-bold text-white mb-2 flex items-center gap-2">
                    <Brain className="w-5 h-5 text-indigo-400" />
                    AI Provider
                  </h2>
                  <p className="text-sm text-slate-400 mb-6">
                    Choose your AI provider. CreatorOS AI works with any provider.
                  </p>

                  <div className="space-y-3 mb-6">
                    {AI_PROVIDERS.map(provider => (
                      <div
                        key={provider.id}
                        onClick={() => setSelectedProvider(provider.id as typeof selectedProvider)}
                        className={clsx(
                          'flex items-center gap-4 p-4 rounded-xl border cursor-pointer transition-all',
                          selectedProvider === provider.id
                            ? 'border-indigo-500/50 bg-indigo-500/10'
                            : 'border-slate-800 hover:border-slate-700 hover:bg-slate-900/50'
                        )}
                      >
                        <div className={clsx(
                          'w-5 h-5 rounded-full border-2 flex items-center justify-center flex-shrink-0',
                          selectedProvider === provider.id ? 'border-indigo-400' : 'border-slate-600'
                        )}>
                          {selectedProvider === provider.id && (
                            <div className="w-2.5 h-2.5 rounded-full bg-indigo-400" />
                          )}
                        </div>
                        <div className="flex-1">
                          <div className="flex items-center gap-2">
                            <span className="font-medium text-white text-sm">{provider.name}</span>
                            <Badge variant="gray" className="text-xs py-0">{provider.badge}</Badge>
                          </div>
                          <p className="text-xs text-slate-400">{provider.desc}</p>
                        </div>
                        {selectedProvider === provider.id && (
                          <CheckCircle className="w-4 h-4 text-indigo-400 flex-shrink-0" />
                        )}
                      </div>
                    ))}
                  </div>

                  {/* API Key Input */}
                  {selectedProvider !== 'mock' && (
                    <div className="mb-6">
                      <label className="block text-sm font-medium text-slate-300 mb-2 flex items-center gap-2">
                        <Key className="w-4 h-4 text-slate-400" />
                        API Key
                      </label>
                      <div className="relative">
                        <input
                          type={showApiKey ? 'text' : 'password'}
                          value={apiKey}
                          onChange={e => setApiKey(e.target.value)}
                          placeholder="sk-..."
                          className="input-dark pr-10"
                        />
                        <button
                          type="button"
                          onClick={() => setShowApiKey(!showApiKey)}
                          className="absolute right-3.5 top-1/2 -translate-y-1/2 text-slate-500 hover:text-slate-300 cursor-pointer"
                        >
                          {showApiKey ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                        </button>
                      </div>
                      <div className="flex items-center gap-2 mt-2 text-xs text-slate-500">
                        <Shield className="w-3.5 h-3.5 text-emerald-400" />
                        <span>Your API key is stored locally and never sent to our servers.</span>
                      </div>
                      <a
                        href={
                          selectedProvider === 'openai' ? 'https://platform.openai.com/api-keys' :
                          selectedProvider === 'claude' ? 'https://console.anthropic.com/settings/keys' :
                          selectedProvider === 'deepseek' ? 'https://platform.deepseek.com' :
                          'https://integrate.api.nvidia.com'
                        }
                        target="_blank"
                        rel="noopener noreferrer"
                        className="inline-flex items-center gap-1 text-xs text-indigo-400 hover:text-indigo-300 mt-2"
                      >
                        Get your API key <ExternalLink className="w-3 h-3" />
                      </a>
                    </div>
                  )}

                  {selectedProvider === 'mock' && (
                    <div className="mb-6 p-4 rounded-xl bg-indigo-500/10 border border-indigo-500/20 flex items-start gap-2">
                      <AlertCircle className="w-4 h-4 text-indigo-400 flex-shrink-0 mt-0.5" />
                      <p className="text-xs text-indigo-300">
                        Using Mock AI. Responses are pre-generated templates. Add a real API key above for live AI generation.
                      </p>
                    </div>
                  )}

                  <Button icon={<Save className="w-4 h-4" />} onClick={handleSaveAI}>
                    Save AI Settings
                  </Button>
                </GlassCard>

                {/* Default Output Settings */}
                <GlassCard padding="lg">
                  <h2 className="text-lg font-bold text-white mb-6">Default Output Settings</h2>
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-6">
                    <div>
                      <label className="block text-sm font-medium text-slate-300 mb-2">Default Tone</label>
                      <select
                        value={settings.tone}
                        onChange={e => updateSettings({ tone: e.target.value })}
                        className="input-dark"
                      >
                        {TONES.map(t => (
                          <option key={t} value={t.toLowerCase()}>{t}</option>
                        ))}
                      </select>
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-slate-300 mb-2">Default Language</label>
                      <select
                        value={settings.language}
                        onChange={e => updateSettings({ language: e.target.value })}
                        className="input-dark"
                      >
                        {LANGUAGES.map(l => (
                          <option key={l} value={l}>{l}</option>
                        ))}
                      </select>
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-slate-300 mb-2">Output Length</label>
                      <select
                        value={settings.outputLength}
                        onChange={e => updateSettings({ outputLength: e.target.value as 'short' | 'medium' | 'long' })}
                        className="input-dark"
                      >
                        <option value="short">Short (150-300 words)</option>
                        <option value="medium">Medium (300-600 words)</option>
                        <option value="long">Long (600-1000 words)</option>
                      </select>
                    </div>
                  </div>
                  <Button variant="secondary" icon={<Save className="w-4 h-4" />} onClick={handleSaveDefaults}>
                    Save Defaults
                  </Button>
                </GlassCard>
              </>
            )}

            {/* ─── Billing Tab ─── */}
            {activeTab === 'billing' && (
              <GlassCard padding="lg">
                <h2 className="text-lg font-bold text-white mb-6 flex items-center gap-2">
                  <CreditCard className="w-5 h-5 text-indigo-400" />
                  Billing & Subscription
                </h2>

                {/* Current Plan */}
                <div className="p-5 rounded-2xl bg-gradient-to-r from-indigo-500/10 to-violet-500/5 border border-indigo-500/30 mb-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <div className="flex items-center gap-2 mb-1">
                        <Crown className="w-4 h-4 text-yellow-400" />
                        <span className="text-sm font-medium text-slate-300">Current Plan</span>
                      </div>
                      <p className="text-2xl font-bold text-white capitalize">{user?.plan} Plan</p>
                      <p className="text-sm text-slate-400 mt-1">
                        {user?.generationsUsed}/{user?.generationsLimit} generations used this month
                      </p>
                    </div>
                    <Link to="/pricing">
                      <Button size="sm">
                        {user?.plan === 'agency' ? 'Manage Plan' : 'Upgrade Plan'}
                      </Button>
                    </Link>
                  </div>

                  {/* Usage bar */}
                  <div className="mt-4">
                    <div className="progress-bar h-2">
                      <div
                        className="progress-fill h-full"
                        style={{ width: `${Math.min(((user?.generationsUsed || 0) / (user?.generationsLimit || 10)) * 100, 100)}%` }}
                      />
                    </div>
                  </div>
                </div>

                {/* Payment Methods */}
                <div className="mb-6">
                  <h3 className="text-sm font-semibold text-white mb-3">Payment Methods</h3>
                  <div className="p-4 rounded-xl border border-slate-800/60 bg-slate-900/40 text-center">
                    <p className="text-slate-400 text-sm mb-3">No payment method added yet.</p>
                    <Button
                      variant="secondary"
                      size="sm"
                      icon={<CreditCard className="w-4 h-4" />}
                      onClick={() => toast('Payment integration ready. Connect Razorpay/Stripe to enable.', { icon: '💳' })}
                    >
                      Add Payment Method
                    </Button>
                  </div>
                </div>

                {/* Payment Providers Note */}
                <div className="p-4 rounded-xl bg-slate-900/40 border border-slate-800/50">
                  <p className="text-xs text-slate-400 leading-relaxed">
                    💳 <strong className="text-slate-300">Payment Integration:</strong> CreatorOS AI supports{' '}
                    <strong className="text-indigo-300">Razorpay</strong> (UPI, NetBanking, Cards) and{' '}
                    <strong className="text-indigo-300">Stripe</strong> (International). 
                    Add your payment gateway keys in the .env file to enable subscriptions.
                  </p>
                </div>
              </GlassCard>
            )}

            {/* ─── Notifications Tab ─── */}
            {activeTab === 'notifications' && (
              <GlassCard padding="lg">
                <h2 className="text-lg font-bold text-white mb-6 flex items-center gap-2">
                  <Bell className="w-5 h-5 text-indigo-400" />
                  Notification Preferences
                </h2>
                <div className="space-y-4">
                  {[
                    { label: 'Email Notifications', desc: 'Receive email updates about your account', state: emailNotifs, setState: setEmailNotifs },
                    { label: 'Weekly Report', desc: 'Get a weekly summary of your content performance', state: weeklyReport, setState: setWeeklyReport },
                    { label: 'Product Updates', desc: 'Be notified about new features and tools', state: productUpdates, setState: setProductUpdates },
                  ].map(item => (
                    <div key={item.label} className="flex items-center justify-between p-4 rounded-xl border border-slate-800/50 bg-slate-900/30">
                      <div>
                        <p className="text-sm font-medium text-white">{item.label}</p>
                        <p className="text-xs text-slate-400">{item.desc}</p>
                      </div>
                      <button
                        onClick={() => {
                          item.setState(!item.state);
                          toast.success('Preference updated');
                        }}
                        className={clsx(
                          'relative w-11 h-6 rounded-full transition-colors cursor-pointer',
                          item.state ? 'bg-indigo-500' : 'bg-slate-700'
                        )}
                      >
                        <div className={clsx(
                          'absolute top-1 w-4 h-4 rounded-full bg-white transition-transform',
                          item.state ? 'translate-x-6' : 'translate-x-1'
                        )} />
                      </button>
                    </div>
                  ))}
                </div>
                <div className="mt-6">
                  <Button icon={<Save className="w-4 h-4" />} onClick={() => toast.success('Notification preferences saved!')}>
                    Save Preferences
                  </Button>
                </div>
              </GlassCard>
            )}

            {/* ─── Security Tab ─── */}
            {activeTab === 'security' && (
              <GlassCard padding="lg">
                <h2 className="text-lg font-bold text-white mb-6 flex items-center gap-2">
                  <Shield className="w-5 h-5 text-indigo-400" />
                  Security Settings
                </h2>
                <div className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium text-slate-300 mb-2">Current Password</label>
                    <input type="password" placeholder="••••••••" className="input-dark" />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-slate-300 mb-2">New Password</label>
                    <input type="password" placeholder="Min. 8 characters" className="input-dark" />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-slate-300 mb-2">Confirm New Password</label>
                    <input type="password" placeholder="Repeat new password" className="input-dark" />
                  </div>
                  <Button icon={<Shield className="w-4 h-4" />} onClick={() => toast.success('Password updated! 🔐')}>
                    Update Password
                  </Button>
                </div>

                <div className="mt-8 p-4 rounded-xl bg-emerald-500/5 border border-emerald-500/20">
                  <div className="flex items-center gap-2 mb-2">
                    <CheckCircle className="w-4 h-4 text-emerald-400" />
                    <span className="text-sm font-medium text-emerald-300">Account Security Status</span>
                  </div>
                  <p className="text-xs text-slate-400">
                    Your account is secured. API keys are stored locally in your browser.
                    Enable 2FA for additional protection (coming soon).
                  </p>
                </div>
              </GlassCard>
            )}
          </div>
        </div>
      </div>
    </DashboardLayout>
  );
}
