// =========================================
// CreatorOS AI – History Page
// View, search, and manage all past generations
// =========================================

import { useState } from 'react';
import { Link } from 'react-router-dom';
import {
  Search, Bookmark, BookmarkCheck, Trash2, Copy, Filter,
  Calendar, Clock, RotateCcw
} from 'lucide-react';
import DashboardLayout from '../components/layout/DashboardLayout';
import GlassCard from '../components/ui/GlassCard';
import Button from '../components/ui/Button';
import Badge from '../components/ui/Badge';
import { useApp } from '../context/AppContext';
import { TOOLS } from '../data/tools';
import { formatDistanceToNow, format } from 'date-fns';
import toast from 'react-hot-toast';

type FilterType = 'all' | 'saved' | string;

export default function History() {
  const { history, toggleSaved, deleteHistoryItem, clearHistory } = useApp();
  const [searchQuery, setSearchQuery] = useState('');
  const [filter, setFilter] = useState<FilterType>('all');
  const [expandedId, setExpandedId] = useState<string | null>(null);

  // Filter and search logic
  const filteredHistory = history.filter(item => {
    const matchesSearch =
      searchQuery === '' ||
      item.input.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.toolName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.output.toLowerCase().includes(searchQuery.toLowerCase());

    const matchesFilter =
      filter === 'all' ||
      (filter === 'saved' && item.saved) ||
      item.toolId === filter;

    return matchesSearch && matchesFilter;
  });

  const handleCopy = async (output: string) => {
    try {
      await navigator.clipboard.writeText(output);
      toast.success('Copied to clipboard! 📋');
    } catch {
      toast.error('Failed to copy');
    }
  };

  const handleDelete = (id: string) => {
    deleteHistoryItem(id);
    toast.success('Deleted from history');
  };

  const handleClearAll = () => {
    if (window.confirm('Are you sure you want to clear all history? This cannot be undone.')) {
      clearHistory();
      toast.success('History cleared');
    }
  };

  const savedCount = history.filter(h => h.saved).length;

  return (
    <DashboardLayout title="History" subtitle="All your AI-generated content">
      <div className="max-w-5xl mx-auto space-y-6 fade-in">

        {/* Stats Row */}
        <div className="grid grid-cols-3 gap-4">
          <GlassCard padding="md" className="text-center">
            <div className="text-2xl font-bold text-white">{history.length}</div>
            <div className="text-xs text-slate-400 mt-1">Total Generated</div>
          </GlassCard>
          <GlassCard padding="md" className="text-center">
            <div className="text-2xl font-bold text-violet-400">{savedCount}</div>
            <div className="text-xs text-slate-400 mt-1">Saved Items</div>
          </GlassCard>
          <GlassCard padding="md" className="text-center">
            <div className="text-2xl font-bold text-cyan-400">
              {new Set(history.map(h => h.toolId)).size}
            </div>
            <div className="text-xs text-slate-400 mt-1">Tools Used</div>
          </GlassCard>
        </div>

        {/* Controls */}
        <GlassCard padding="md">
          <div className="flex flex-col sm:flex-row gap-3">
            {/* Search */}
            <div className="relative flex-1">
              <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500" />
              <input
                type="text"
                value={searchQuery}
                onChange={e => setSearchQuery(e.target.value)}
                placeholder="Search history..."
                className="input-dark pl-10"
              />
            </div>

            {/* Filter */}
            <div className="flex items-center gap-2">
              <Filter className="w-4 h-4 text-slate-500 flex-shrink-0" />
              <select
                value={filter}
                onChange={e => setFilter(e.target.value)}
                className="input-dark py-2"
              >
                <option value="all">All Tools</option>
                <option value="saved">⭐ Saved Only</option>
                {TOOLS.map(t => (
                  <option key={t.id} value={t.id}>{t.icon} {t.name}</option>
                ))}
              </select>
            </div>

            {/* Clear All */}
            {history.length > 0 && (
              <Button variant="danger" size="md" icon={<Trash2 className="w-4 h-4" />} onClick={handleClearAll}>
                Clear All
              </Button>
            )}
          </div>
        </GlassCard>

        {/* History List */}
        {filteredHistory.length === 0 ? (
          <GlassCard padding="lg" className="text-center">
            <div className="text-5xl mb-4">📂</div>
            <h3 className="text-lg font-semibold text-white mb-2">
              {history.length === 0 ? 'No history yet' : 'No results found'}
            </h3>
            <p className="text-slate-400 text-sm mb-6">
              {history.length === 0
                ? "Your generated content will appear here. Start generating!"
                : "Try a different search term or filter."}
            </p>
            {history.length === 0 && (
              <Link to="/dashboard">
                <Button icon={<RotateCcw className="w-4 h-4" />}>Go to Dashboard</Button>
              </Link>
            )}
          </GlassCard>
        ) : (
          <div className="space-y-3">
            {filteredHistory.map(item => {
              const tool = TOOLS.find(t => t.id === item.toolId);
              const isExpanded = expandedId === item.id;

              return (
                <GlassCard key={item.id} padding="none">
                  {/* Header */}
                  <div
                    className="p-4 cursor-pointer"
                    onClick={() => setExpandedId(isExpanded ? null : item.id)}
                  >
                    <div className="flex items-start gap-3">
                      {/* Tool Icon */}
                      <div
                        className="w-10 h-10 rounded-xl flex items-center justify-center text-lg flex-shrink-0"
                        style={{ background: tool?.bgColor || 'rgba(99,102,241,0.1)' }}
                      >
                        {tool?.icon || '⚡'}
                      </div>

                      {/* Content */}
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 mb-1 flex-wrap">
                          <span className="text-sm font-semibold text-white">{item.toolName}</span>
                          {item.saved && (
                            <Badge variant="purple" className="text-xs py-0">
                              <BookmarkCheck className="w-2.5 h-2.5 inline mr-0.5" />
                              Saved
                            </Badge>
                          )}
                        </div>
                        <p className="text-xs text-slate-400 truncate mb-1">
                          <span className="text-slate-500">Input: </span>{item.input}
                        </p>
                        <p className="text-xs text-slate-500 line-clamp-1 font-mono">
                          {item.output.substring(0, 100)}...
                        </p>
                      </div>

                      {/* Meta */}
                      <div className="flex flex-col items-end gap-2 flex-shrink-0">
                        <div className="flex items-center gap-1 text-xs text-slate-600">
                          <Clock className="w-3 h-3" />
                          {formatDistanceToNow(new Date(item.createdAt), { addSuffix: true })}
                        </div>
                        <div className="flex items-center gap-1 text-xs text-slate-600">
                          <Calendar className="w-3 h-3" />
                          {format(new Date(item.createdAt), 'MMM d, yyyy')}
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Expanded Output */}
                  {isExpanded && (
                    <div className="px-4 pb-4 border-t border-slate-800/50">
                      <div className="mt-4">
                        {/* Full Input */}
                        <div className="mb-3 p-3 rounded-xl bg-slate-900/60 border border-slate-800/50">
                          <p className="text-xs text-slate-500 mb-1 font-medium uppercase tracking-wider">Input</p>
                          <p className="text-sm text-slate-300">{item.input}</p>
                        </div>

                        {/* Output Box */}
                        <div className="output-box mb-3 max-h-64 overflow-y-auto text-xs">
                          {item.output}
                        </div>

                        {/* Actions */}
                        <div className="flex flex-wrap gap-2">
                          <Button
                            size="sm"
                            variant="primary"
                            icon={<Copy className="w-3.5 h-3.5" />}
                            onClick={() => handleCopy(item.output)}
                          >
                            Copy
                          </Button>
                          <Button
                            size="sm"
                            variant="secondary"
                            icon={item.saved ? <BookmarkCheck className="w-3.5 h-3.5" /> : <Bookmark className="w-3.5 h-3.5" />}
                            onClick={() => {
                              toggleSaved(item.id);
                              toast.success(item.saved ? 'Removed from saved' : 'Saved! 🔖');
                            }}
                          >
                            {item.saved ? 'Unsave' : 'Save'}
                          </Button>
                          <Link to={`/tool/${item.toolId}`}>
                            <Button size="sm" variant="ghost" icon={<RotateCcw className="w-3.5 h-3.5" />}>
                              Use Again
                            </Button>
                          </Link>
                          <Button
                            size="sm"
                            variant="danger"
                            icon={<Trash2 className="w-3.5 h-3.5" />}
                            onClick={() => handleDelete(item.id)}
                          >
                            Delete
                          </Button>
                        </div>
                      </div>
                    </div>
                  )}
                </GlassCard>
              );
            })}
          </div>
        )}

        {/* Pagination info */}
        {filteredHistory.length > 0 && (
          <p className="text-center text-xs text-slate-600">
            Showing {filteredHistory.length} of {history.length} total generations
          </p>
        )}
      </div>
    </DashboardLayout>
  );
}
