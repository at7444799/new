// =========================================
// CreatorOS AI – Results Page
// Standalone results page after generation
// =========================================

import { Link, useLocation, Navigate } from 'react-router-dom';
import { Copy, Bookmark, RotateCcw, Download, ChevronLeft, Share2 } from 'lucide-react';
import DashboardLayout from '../components/layout/DashboardLayout';
import GlassCard from '../components/ui/GlassCard';
import Button from '../components/ui/Button';
import { TOOLS } from '../data/tools';
import toast from 'react-hot-toast';

interface ResultsState {
  toolId: string;
  input: string;
  output: string;
}

export default function Results() {
  const location = useLocation();
  const state = location.state as ResultsState | null;

  if (!state) return <Navigate to="/dashboard" replace />;

  const tool = TOOLS.find(t => t.id === state.toolId);

  const handleCopy = async () => {
    await navigator.clipboard.writeText(state.output);
    toast.success('Copied! 📋');
  };

  const handleDownload = () => {
    const blob = new Blob([state.output], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${state.toolId}-${Date.now()}.txt`;
    a.click();
    URL.revokeObjectURL(url);
    toast.success('Downloaded!');
  };

  return (
    <DashboardLayout title="Generation Results">
      <div className="max-w-3xl mx-auto space-y-6 fade-in">
        <div className="flex items-center gap-2 text-sm">
          <Link to="/dashboard" className="text-slate-500 hover:text-slate-300 flex items-center gap-1">
            <ChevronLeft className="w-4 h-4" /> Dashboard
          </Link>
          <span className="text-slate-700">/</span>
          <span className="text-indigo-300">Results</span>
        </div>

        <GlassCard padding="lg">
          <div className="flex items-center gap-3 mb-6">
            <div className="text-3xl">{tool?.icon || '⚡'}</div>
            <div>
              <h2 className="text-xl font-bold text-white">{tool?.name || 'AI Tool'}</h2>
              <p className="text-sm text-slate-400">Input: {state.input}</p>
            </div>
          </div>

          <div className="output-box mb-6">{state.output}</div>

          <div className="flex flex-wrap gap-3">
            <Button icon={<Copy className="w-4 h-4" />} onClick={handleCopy}>Copy All</Button>
            <Button variant="secondary" icon={<Bookmark className="w-4 h-4" />} onClick={() => toast.success('Saved!')}>Save</Button>
            <Button variant="ghost" icon={<Download className="w-4 h-4" />} onClick={handleDownload}>Download</Button>
            <Button variant="ghost" icon={<Share2 className="w-4 h-4" />} onClick={handleCopy}>Share</Button>
            <Link to={`/tool/${state.toolId}`}>
              <Button variant="outline" icon={<RotateCcw className="w-4 h-4" />}>Generate Again</Button>
            </Link>
          </div>
        </GlassCard>

        <div className="text-center">
          <Link to="/dashboard">
            <Button variant="ghost" icon={<ChevronLeft className="w-4 h-4" />}>Back to Dashboard</Button>
          </Link>
        </div>
      </div>
    </DashboardLayout>
  );
}
