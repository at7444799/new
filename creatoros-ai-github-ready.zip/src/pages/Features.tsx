// =========================================
// CreatorOS AI – Features Page
// =========================================

import { Link } from 'react-router-dom';
import { ArrowRight, CheckCircle, Zap } from 'lucide-react';
import Navbar from '../components/layout/Navbar';
import Button from '../components/ui/Button';
import GlassCard from '../components/ui/GlassCard';
import Badge from '../components/ui/Badge';
import { TOOLS } from '../data/tools';

const PLATFORM_SUPPORT = [
  { name: 'YouTube', emoji: '▶️', desc: 'Titles, descriptions, scripts, shorts' },
  { name: 'Instagram', emoji: '📸', desc: 'Captions, reels hooks, hashtags' },
  { name: 'TikTok', emoji: '🎵', desc: 'Short-form scripts, trends, hooks' },
  { name: 'LinkedIn', emoji: '💼', desc: 'Professional posts, articles' },
  { name: 'Twitter/X', emoji: '🐦', desc: 'Threads, tweets, hooks' },
  { name: 'Facebook', emoji: '👥', desc: 'Ad copy, group posts' },
  { name: 'Blog', emoji: '📝', desc: 'Full SEO articles, meta content' },
  { name: 'Email', emoji: '📧', desc: 'Subject lines, newsletters' },
];

const HOW_IT_WORKS = [
  {
    step: '01',
    title: 'Choose Your Tool',
    desc: 'Select from 10 specialized AI tools built for specific content types.',
    color: 'from-indigo-500 to-violet-500',
  },
  {
    step: '02',
    title: 'Enter Your Topic',
    desc: 'Type your idea, product, or topic. Our AI understands context deeply.',
    color: 'from-violet-500 to-pink-500',
  },
  {
    step: '03',
    title: 'Generate & Customize',
    desc: 'Get multiple variations instantly. Tweak tone, length, and style.',
    color: 'from-cyan-500 to-blue-500',
  },
  {
    step: '04',
    title: 'Copy & Publish',
    desc: 'One-click copy. Save to history. Publish directly to your platforms.',
    color: 'from-emerald-500 to-teal-500',
  },
];

export default function Features() {
  return (
    <div className="min-h-screen bg-slate-950 text-slate-100">
      <Navbar />

      <div className="pt-24">
        {/* Hero */}
        <section className="py-20 text-center relative overflow-hidden">
          <div className="absolute inset-0 bg-gradient-hero grid-pattern" />
          <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[400px] bg-indigo-500/10 blur-3xl rounded-full" />

          <div className="relative max-w-4xl mx-auto px-4">
            <Badge variant="blue" dot className="mb-6">Features Overview</Badge>
            <h1 className="text-4xl sm:text-6xl font-extrabold text-white mb-6">
              10 Tools, <span className="gradient-text">Infinite Possibilities</span>
            </h1>
            <p className="text-xl text-slate-400 mb-10 max-w-2xl mx-auto">
              Every tool you need to create, optimize, and scale your content — all in one powerful platform.
            </p>
            <Link to="/register">
              <Button size="xl" icon={<Zap className="w-5 h-5 fill-white" />} iconRight={<ArrowRight className="w-5 h-5" />}>
                Start Free Today
              </Button>
            </Link>
          </div>
        </section>

        {/* Tools Detail Grid */}
        <section className="py-20 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl font-bold text-white text-center mb-12">All 10 AI Tools</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {TOOLS.map((tool, idx) => (
              <Link to={`/tool/${tool.id}`} key={tool.id}>
                <GlassCard hover padding="lg" className="h-full group">
                  <div className="flex items-start gap-4">
                    <div
                      className="w-14 h-14 rounded-2xl flex items-center justify-center text-2xl flex-shrink-0"
                      style={{ background: tool.bgColor, border: `1px solid ${tool.color}30` }}
                    >
                      {tool.icon}
                    </div>
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-1">
                        <h3 className="font-bold text-white">{tool.name}</h3>
                        {tool.badge && (
                          <Badge variant={tool.badge === 'Hot' ? 'red' : tool.badge === 'New' ? 'green' : 'purple'}>
                            {tool.badge}
                          </Badge>
                        )}
                      </div>
                      <p className="text-slate-400 text-sm mb-3">{tool.description}</p>
                      <div className="flex items-center gap-1 text-sm font-semibold opacity-0 group-hover:opacity-100 transition-opacity" style={{ color: tool.color }}>
                        Try {tool.name} <ArrowRight className="w-4 h-4" />
                      </div>
                    </div>
                    <span className="text-2xl opacity-20 font-bold text-slate-600">
                      {String(idx + 1).padStart(2, '0')}
                    </span>
                  </div>
                </GlassCard>
              </Link>
            ))}
          </div>
        </section>

        {/* How It Works */}
        <section className="py-20 bg-gradient-section">
          <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center mb-16">
              <Badge variant="cyan" className="mb-4">Simple Process</Badge>
              <h2 className="text-3xl sm:text-4xl font-bold text-white">
                From Idea to Content in <span className="gradient-text">4 Steps</span>
              </h2>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
              {HOW_IT_WORKS.map((step) => (
                <div key={step.step} className="text-center">
                  <div className={`w-16 h-16 rounded-2xl bg-gradient-to-br ${step.color} flex items-center justify-center mx-auto mb-4 shadow-lg`}>
                    <span className="text-2xl font-extrabold text-white">{step.step}</span>
                  </div>
                  <h3 className="font-bold text-white mb-2">{step.title}</h3>
                  <p className="text-sm text-slate-400 leading-relaxed">{step.desc}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Platform Support */}
        <section className="py-20">
          <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center mb-16">
              <Badge variant="purple" className="mb-4">Multi-Platform</Badge>
              <h2 className="text-3xl sm:text-4xl font-bold text-white mb-4">
                Works Across All Your <span className="gradient-text">Platforms</span>
              </h2>
              <p className="text-slate-400 max-w-xl mx-auto">
                Content optimized for the specific algorithm and audience of each platform.
              </p>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
              {PLATFORM_SUPPORT.map(platform => (
                <GlassCard key={platform.name} hover padding="md" className="text-center">
                  <div className="text-3xl mb-2">{platform.emoji}</div>
                  <h4 className="font-semibold text-white mb-1">{platform.name}</h4>
                  <p className="text-xs text-slate-500">{platform.desc}</p>
                </GlassCard>
              ))}
            </div>
          </div>
        </section>

        {/* AI Provider Section */}
        <section className="py-20 bg-gradient-section">
          <div className="max-w-4xl mx-auto px-4 text-center">
            <Badge variant="yellow" className="mb-6">Flexible AI Backend</Badge>
            <h2 className="text-3xl sm:text-4xl font-bold text-white mb-6">
              Use Any AI Model You Want
            </h2>
            <p className="text-slate-400 mb-10 text-lg">
              CreatorOS AI is provider-agnostic. Connect your own API key and choose your preferred AI model.
            </p>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 mb-10">
              {[
                { name: 'OpenAI', model: 'GPT-4o', badge: 'blue' },
                { name: 'Claude', model: 'Claude 3', badge: 'purple' },
                { name: 'DeepSeek', model: 'DeepSeek Chat', badge: 'cyan' },
                { name: 'NVIDIA', model: 'NIM API', badge: 'green' },
              ].map(provider => (
                <GlassCard key={provider.name} padding="md" className="text-center">
                  <div className="font-bold text-white mb-1">{provider.name}</div>
                  <div className="text-xs text-slate-400">{provider.model}</div>
                  <Badge variant={provider.badge as 'blue' | 'purple' | 'cyan' | 'green'} className="mt-2 mx-auto">Ready</Badge>
                </GlassCard>
              ))}
            </div>

            <div className="space-y-3 text-left max-w-md mx-auto mb-10">
              {[
                'Add your API key in Settings',
                'Switch providers anytime with zero downtime',
                'Uses mock AI by default (no key needed)',
                'Full control over model parameters',
              ].map(feat => (
                <div key={feat} className="flex items-center gap-3">
                  <CheckCircle className="w-4 h-4 text-emerald-400 flex-shrink-0" />
                  <span className="text-slate-300 text-sm">{feat}</span>
                </div>
              ))}
            </div>

            <Link to="/settings">
              <Button size="lg">Configure AI Settings</Button>
            </Link>
          </div>
        </section>

        {/* CTA */}
        <section className="py-20 text-center">
          <div className="max-w-3xl mx-auto px-4">
            <h2 className="text-4xl font-bold text-white mb-4">
              Ready to <span className="gradient-text">10x Your Content?</span>
            </h2>
            <p className="text-slate-400 mb-8">Start with 10 free generations. No credit card needed.</p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Link to="/register">
                <Button size="xl">Get Started Free</Button>
              </Link>
              <Link to="/pricing">
                <Button size="xl" variant="secondary">View Pricing</Button>
              </Link>
            </div>
          </div>
        </section>
      </div>
    </div>
  );
}
