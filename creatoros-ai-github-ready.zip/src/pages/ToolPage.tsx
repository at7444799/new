// =========================================
// CreatorOS AI – Tool Page
// Individual AI tool interface with input, generation, and output
// =========================================

import { useState, useRef } from 'react';
import { useParams, Link, Navigate } from 'react-router-dom';
import {
  Sparkles, Copy, RotateCcw, Download, BookmarkCheck,
  Bookmark, ChevronLeft, Share2, Settings, AlertCircle
} from 'lucide-react';
import DashboardLayout from '../components/layout/DashboardLayout';
import GlassCard from '../components/ui/GlassCard';
import Button from '../components/ui/Button';
import Badge from '../components/ui/Badge';
import { AIGeneratingAnimation } from '../components/ui/LoadingSpinner';
import { useApp } from '../context/AppContext';
import { TOOLS, LANGUAGES, TONES } from '../data/tools';
import { generateContent } from '../services/aiService';
import { ToolId } from '../types';
import toast from 'react-hot-toast';

export default function ToolPage() {
  const { toolId } = useParams<{ toolId: string }>();
  const { user, settings, addToHistory, incrementGenerations, canGenerate } = useApp();

  const tool = TOOLS.find(t => t.id === toolId);

  // State
  const [input, setInput] = useState('');
  const [output, setOutput] = useState('');
  const [isGenerating, setIsGenerating] = useState(false);
  const [isSaved, setIsSaved] = useState(false);
  const [outputTone, setOutputTone] = useState(settings.tone);
  const [outputLanguage, setOutputLanguage] = useState(settings.language);
  const [outputLength, setOutputLength] = useState<'short' | 'medium' | 'long'>(settings.outputLength);
  const [showSettings, setShowSettings] = useState(false);
  const outputRef = useRef<HTMLDivElement>(null);

  if (!tool) return <Navigate to="/dashboard" replace />;

  const handleGenerate = async () => {
    if (!input.trim()) {
      toast.error('Please enter a topic or idea first');
      return;
    }
    if (!canGenerate) {
      toast.error('You\'ve reached your generation limit. Please upgrade your plan.');
      return;
    }

    setIsGenerating(true);
    setOutput('');
    setIsSaved(false);

    try {
      const result = await generateContent(
        { toolId: tool.id as ToolId, input: input.trim() },
        { ...settings, tone: outputTone, language: outputLanguage, outputLength }
      );

      setOutput(result.output);
      incrementGenerations();

      // Auto-add to history
      addToHistory({
        toolId: tool.id as ToolId,
        toolName: tool.name,
        input: input.trim(),
        output: result.output,
        saved: false,
      });

      toast.success('Content generated! ✨');

      // Scroll to output
      setTimeout(() => {
        outputRef.current?.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
      }, 100);
    } catch (err) {
      toast.error('Generation failed. Please try again.');
      console.error(err);
    } finally {
      setIsGenerating(false);
    }
  };

  const handleCopy = async () => {
    try {
      await navigator.clipboard.writeText(output);
      toast.success('Copied to clipboard! 📋');
    } catch {
      toast.error('Failed to copy. Please copy manually.');
    }
  };

  const handleSave = () => {
    setIsSaved(!isSaved);
    toast.success(isSaved ? 'Removed from saved' : 'Saved to your library! 🔖');
  };

  const handleDownload = () => {
    const blob = new Blob([output], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${tool.id}-output-${Date.now()}.txt`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    toast.success('Downloaded! 📥');
  };

  const handleRegenerate = () => {
    if (input.trim()) handleGenerate();
  };

  const handleShare = async () => {
    if (navigator.share) {
      await navigator.share({ title: 'CreatorOS AI Output', text: output });
    } else {
      handleCopy();
    }
  };

  const characterCount = input.length;
  const wordCount = input.trim() ? input.trim().split(/\s+/).length : 0;

  return (
    <DashboardLayout title={tool.name} subtitle={tool.description}>
      <div className="max-w-5xl mx-auto space-y-6 fade-in">

        {/* Breadcrumb */}
        <div className="flex items-center gap-2 text-sm">
          <Link to="/dashboard" className="text-slate-500 hover:text-slate-300 flex items-center gap-1 transition-colors">
            <ChevronLeft className="w-4 h-4" />
            Dashboard
          </Link>
          <span className="text-slate-700">/</span>
          <span className="text-indigo-300">{tool.name}</span>
        </div>

        {/* Tool Header */}
        <GlassCard padding="md" className="bg-gradient-to-r from-slate-900/80 to-slate-900/40">
          <div className="flex items-center gap-4">
            <div
              className="w-14 h-14 rounded-2xl flex items-center justify-center text-2xl flex-shrink-0"
              style={{ background: tool.bgColor, border: `1px solid ${tool.color}30` }}
            >
              {tool.icon}
            </div>
            <div className="flex-1">
              <div className="flex items-center gap-2 mb-1">
                <h1 className="text-xl font-bold text-white">{tool.name}</h1>
                {tool.badge && (
                  <Badge variant={tool.badge === 'Hot' ? 'red' : tool.badge === 'New' ? 'green' : 'purple'}>
                    {tool.badge}
                  </Badge>
                )}
                <Badge variant="gray" className="ml-auto">
                  {user?.generationsLimit ? user.generationsLimit - (user?.generationsUsed || 0) : 0} left
                </Badge>
              </div>
              <p className="text-sm text-slate-400">{tool.description}</p>
            </div>
          </div>
        </GlassCard>

        <div className="grid grid-cols-1 xl:grid-cols-2 gap-6">
          {/* ─── Input Panel ─────────────────────────────── */}
          <div className="space-y-4">
            <GlassCard padding="none">
              <div className="p-4 border-b border-slate-800/50 flex items-center justify-between">
                <h2 className="font-semibold text-white text-sm flex items-center gap-2">
                  <span className="w-2 h-2 rounded-full bg-indigo-400" />
                  Input
                </h2>
                <button
                  onClick={() => setShowSettings(!showSettings)}
                  className={`flex items-center gap-1.5 text-xs font-medium px-3 py-1.5 rounded-lg transition-all cursor-pointer ${
                    showSettings ? 'bg-indigo-500/20 text-indigo-300 border border-indigo-500/30' : 'text-slate-500 hover:text-slate-300 hover:bg-white/5'
                  }`}
                >
                  <Settings className="w-3.5 h-3.5" />
                  Options
                </button>
              </div>

              {/* Settings Panel */}
              {showSettings && (
                <div className="p-4 border-b border-slate-800/50 bg-slate-900/40 grid grid-cols-3 gap-3">
                  <div>
                    <label className="block text-xs text-slate-400 mb-1.5 font-medium">Tone</label>
                    <select
                      value={outputTone}
                      onChange={e => setOutputTone(e.target.value)}
                      className="input-dark text-xs py-1.5"
                    >
                      {TONES.map(t => <option key={t} value={t.toLowerCase()}>{t}</option>)}
                    </select>
                  </div>
                  <div>
                    <label className="block text-xs text-slate-400 mb-1.5 font-medium">Language</label>
                    <select
                      value={outputLanguage}
                      onChange={e => setOutputLanguage(e.target.value)}
                      className="input-dark text-xs py-1.5"
                    >
                      {LANGUAGES.map(l => <option key={l} value={l}>{l}</option>)}
                    </select>
                  </div>
                  <div>
                    <label className="block text-xs text-slate-400 mb-1.5 font-medium">Length</label>
                    <select
                      value={outputLength}
                      onChange={e => setOutputLength(e.target.value as 'short' | 'medium' | 'long')}
                      className="input-dark text-xs py-1.5"
                    >
                      <option value="short">Short</option>
                      <option value="medium">Medium</option>
                      <option value="long">Long</option>
                    </select>
                  </div>
                </div>
              )}

              <div className="p-4 space-y-3">
                {/* Input Field */}
                <div>
                  <label className="block text-sm font-medium text-slate-300 mb-2">
                    {tool.inputLabel}
                  </label>
                  {tool.inputType === 'textarea' ? (
                    <textarea
                      value={input}
                      onChange={e => setInput(e.target.value)}
                      placeholder={tool.inputPlaceholder}
                      className="input-dark min-h-[140px]"
                      onKeyDown={e => {
                        if (e.key === 'Enter' && e.ctrlKey) handleGenerate();
                      }}
                    />
                  ) : (
                    <input
                      type="text"
                      value={input}
                      onChange={e => setInput(e.target.value)}
                      placeholder={tool.inputPlaceholder}
                      className="input-dark"
                      onKeyDown={e => {
                        if (e.key === 'Enter') handleGenerate();
                      }}
                    />
                  )}
                </div>

                {/* Character count */}
                <div className="flex justify-between text-xs text-slate-600">
                  <span>{wordCount} words</span>
                  <span className={characterCount > 500 ? 'text-yellow-400' : ''}>{characterCount} characters</span>
                </div>

                {/* Example prompts */}
                <div className="flex flex-wrap gap-2">
                  <span className="text-xs text-slate-600">Try:</span>
                  {getExamplePrompts(tool.id as ToolId).map(example => (
                    <button
                      key={example}
                      onClick={() => setInput(example)}
                      className="text-xs px-2 py-1 rounded-lg bg-slate-800/60 text-slate-400 hover:text-indigo-300 hover:bg-indigo-500/10 border border-slate-700/50 hover:border-indigo-500/30 transition-all cursor-pointer"
                    >
                      {example}
                    </button>
                  ))}
                </div>

                {/* Generate Button */}
                {!canGenerate ? (
                  <div className="space-y-3">
                    <div className="flex items-start gap-2 p-3 rounded-xl bg-yellow-500/10 border border-yellow-500/20 text-yellow-400">
                      <AlertCircle className="w-4 h-4 mt-0.5 flex-shrink-0" />
                      <p className="text-xs">You've used all your generations this month.</p>
                    </div>
                    <Link to="/pricing">
                      <Button fullWidth variant="outline">Upgrade to Continue ⚡</Button>
                    </Link>
                  </div>
                ) : (
                  <Button
                    fullWidth
                    size="lg"
                    loading={isGenerating}
                    onClick={handleGenerate}
                    icon={<Sparkles className="w-5 h-5" />}
                    disabled={!input.trim()}
                  >
                    Generate with AI
                  </Button>
                )}

                <p className="text-xs text-center text-slate-600">
                  Press <kbd className="px-1 py-0.5 rounded bg-slate-800 border border-slate-700">Ctrl+Enter</kbd> to generate
                </p>
              </div>
            </GlassCard>
          </div>

          {/* ─── Output Panel ─────────────────────────────── */}
          <div ref={outputRef} className="space-y-4">
            <GlassCard padding="none">
              <div className="p-4 border-b border-slate-800/50 flex items-center justify-between">
                <h2 className="font-semibold text-white text-sm flex items-center gap-2">
                  <span className="w-2 h-2 rounded-full bg-emerald-400" />
                  Output
                </h2>
                {output && (
                  <div className="flex items-center gap-1">
                    <button
                      onClick={handleSave}
                      className={`p-1.5 rounded-lg transition-all cursor-pointer ${isSaved ? 'text-violet-400' : 'text-slate-500 hover:text-slate-300'} hover:bg-white/5`}
                      title={isSaved ? 'Saved' : 'Save'}
                    >
                      {isSaved ? <BookmarkCheck className="w-4 h-4" /> : <Bookmark className="w-4 h-4" />}
                    </button>
                    <button
                      onClick={handleShare}
                      className="p-1.5 rounded-lg text-slate-500 hover:text-slate-300 hover:bg-white/5 transition-all cursor-pointer"
                      title="Share"
                    >
                      <Share2 className="w-4 h-4" />
                    </button>
                    <button
                      onClick={handleDownload}
                      className="p-1.5 rounded-lg text-slate-500 hover:text-slate-300 hover:bg-white/5 transition-all cursor-pointer"
                      title="Download"
                    >
                      <Download className="w-4 h-4" />
                    </button>
                  </div>
                )}
              </div>

              <div className="p-4">
                {isGenerating ? (
                  <AIGeneratingAnimation />
                ) : output ? (
                  <div className="space-y-4">
                    {/* Output Text */}
                    <div className="output-box relative group">
                      {output}
                      <button
                        onClick={handleCopy}
                        className="absolute top-3 right-3 opacity-0 group-hover:opacity-100 transition-opacity p-1.5 rounded-lg bg-slate-800 border border-slate-700 text-slate-400 hover:text-white cursor-pointer"
                        title="Copy"
                      >
                        <Copy className="w-3.5 h-3.5" />
                      </button>
                    </div>

                    {/* Action Buttons */}
                    <div className="flex flex-wrap gap-2">
                      <Button
                        size="sm"
                        variant="primary"
                        icon={<Copy className="w-3.5 h-3.5" />}
                        onClick={handleCopy}
                      >
                        Copy All
                      </Button>
                      <Button
                        size="sm"
                        variant="secondary"
                        icon={isSaved ? <BookmarkCheck className="w-3.5 h-3.5" /> : <Bookmark className="w-3.5 h-3.5" />}
                        onClick={handleSave}
                      >
                        {isSaved ? 'Saved' : 'Save'}
                      </Button>
                      <Button
                        size="sm"
                        variant="ghost"
                        icon={<RotateCcw className="w-3.5 h-3.5" />}
                        onClick={handleRegenerate}
                        loading={isGenerating}
                      >
                        Regenerate
                      </Button>
                      <Button
                        size="sm"
                        variant="ghost"
                        icon={<Download className="w-3.5 h-3.5" />}
                        onClick={handleDownload}
                      >
                        Download
                      </Button>
                    </div>

                    {/* Output Stats */}
                    <div className="flex gap-4 text-xs text-slate-600 border-t border-slate-800/50 pt-3">
                      <span>{output.split(/\s+/).length} words</span>
                      <span>{output.length} characters</span>
                      <span className="ml-auto text-emerald-500/70">✓ Generated successfully</span>
                    </div>
                  </div>
                ) : (
                  /* Empty State */
                  <div className="text-center py-16">
                    <div className="w-16 h-16 rounded-2xl mx-auto mb-4 flex items-center justify-center text-3xl"
                      style={{ background: tool.bgColor }}>
                      {tool.icon}
                    </div>
                    <p className="text-slate-400 text-sm mb-2">Your AI-generated content will appear here</p>
                    <p className="text-slate-600 text-xs">Enter a topic above and click "Generate with AI"</p>
                  </div>
                )}
              </div>
            </GlassCard>

            {/* Related Tools */}
            <GlassCard padding="md">
              <h3 className="text-sm font-semibold text-white mb-3">Related Tools</h3>
              <div className="grid grid-cols-2 gap-2">
                {TOOLS.filter(t => t.id !== tool.id && t.category === tool.category)
                  .slice(0, 2)
                  .concat(TOOLS.filter(t => t.id !== tool.id && t.category !== tool.category).slice(0, 2))
                  .slice(0, 4)
                  .map(relTool => (
                    <Link to={`/tool/${relTool.id}`} key={relTool.id}>
                      <div className="flex items-center gap-2 p-2 rounded-lg hover:bg-slate-800/50 transition-colors cursor-pointer">
                        <span className="text-lg">{relTool.icon}</span>
                        <span className="text-xs text-slate-400 hover:text-slate-200 transition-colors">{relTool.name}</span>
                      </div>
                    </Link>
                  ))}
              </div>
            </GlassCard>
          </div>
        </div>

        {/* Tips Card */}
        <GlassCard padding="md" className="bg-gradient-to-r from-indigo-500/5 to-violet-500/5">
          <div className="flex items-start gap-3">
            <span className="text-xl">💡</span>
            <div>
              <p className="text-sm font-semibold text-white mb-1">Tips for better results</p>
              <p className="text-xs text-slate-400 leading-relaxed">
                {getToolTip(tool.id as ToolId)}
              </p>
            </div>
          </div>
        </GlassCard>
      </div>
    </DashboardLayout>
  );
}

// Example prompts per tool
function getExamplePrompts(toolId: ToolId): string[] {
  const examples: Record<ToolId, string[]> = {
    'shorts-script': ['Morning routine tips', 'How to save money', 'AI side hustles'],
    'viral-hook': ['YouTube growth tips', 'Fitness motivation', 'Passive income ideas'],
    'youtube-title': ['Budget travel in Europe', 'Learn coding fast', '10K followers strategy'],
    'seo-description': ['Best smartphones 2024', 'Digital marketing guide', 'Weight loss tips'],
    'hashtag-generator': ['Photography niche', 'Fitness journey', 'Tech reviews'],
    'thumbnail-prompt': ['I quit my job to travel', 'Gaming setup tour', 'Day in my life'],
    'product-ad-copy': ['Wireless earbuds', 'Skincare serum', 'Online course'],
    'blog-post': ['How to start a podcast', 'SEO for beginners', 'Email marketing tips'],
    'instagram-caption': ['Coffee morning vibes', 'Gym workout complete', 'New city exploration'],
    'content-calendar': ['Fitness + YouTube + IG', 'Tech niche, all platforms', 'Business + LinkedIn'],
  };
  return examples[toolId] || [];
}

// Tips per tool
function getToolTip(toolId: ToolId): string {
  const tips: Record<ToolId, string> = {
    'shorts-script': 'Be specific about your topic. Include your target audience for better scripts. E.g., "5 morning habits for busy entrepreneurs" works better than "morning habits".',
    'viral-hook': 'Mention your niche and what transformation your content promises. The more specific, the more viral the hook.',
    'youtube-title': 'Include your main keyword in the topic. Add context like "2024", "beginner", or "step-by-step" for better CTR.',
    'seo-description': 'Include your primary keyword at least twice. Mention the value viewers get and any specific tools mentioned.',
    'hashtag-generator': 'Combine your niche with broader categories. E.g., "fitness yoga beginner" gives better results than just "yoga".',
    'thumbnail-prompt': 'Include emotion and context. "Person shocked looking at laptop with graph going up" is better than just "success".',
    'product-ad-copy': 'Include key specs, target audience, and main benefit. E.g., "Wireless earbuds with 40hr battery for remote workers".',
    'blog-post': 'Add your target keyword and any subtopics you want covered. Specify length if needed.',
    'instagram-caption': 'Describe the image/video and your message. Include your niche for relevant hashtags in the output.',
    'content-calendar': 'Specify platforms, posting frequency, and niche. E.g., "Finance content, 5x/week, YouTube + Instagram + Twitter".',
  };
  return tips[toolId] || 'Be as specific as possible for the best AI-generated results.';
}
