// =========================================
// CreatorOS AI – Pricing Page
// =========================================

import { useState } from 'react';
import { Link } from 'react-router-dom';
import { Check, X, Zap, Crown, Building2, User } from 'lucide-react';
import Navbar from '../components/layout/Navbar';
import Button from '../components/ui/Button';
import GlassCard from '../components/ui/GlassCard';
import Badge from '../components/ui/Badge';
import { PRICING_PLANS } from '../data/tools';

const FAQ = [
  {
    q: 'Can I switch plans anytime?',
    a: 'Yes, you can upgrade or downgrade your plan at any time. Changes take effect immediately, and you\'ll be billed on a pro-rata basis.',
  },
  {
    q: 'What counts as a "generation"?',
    a: 'Each time you click "Generate" and receive AI output counts as one generation. Regenerating or tweaking the same input counts as a new generation.',
  },
  {
    q: 'Do unused generations roll over?',
    a: 'No, generations reset at the beginning of each billing cycle. We recommend using them throughout the month.',
  },
  {
    q: 'Which AI models are supported?',
    a: 'We support OpenAI (GPT-4), Anthropic Claude, DeepSeek, and NVIDIA NIM. You can bring your own API key or use our built-in AI.',
  },
  {
    q: 'Is there a free trial for paid plans?',
    a: 'The Free plan serves as your trial. You get 10 generations to test all features before upgrading.',
  },
  {
    q: 'Do you support UPI and Indian payment methods?',
    a: 'Yes! We support Razorpay which accepts UPI, Net Banking, Credit/Debit cards, and Wallets.',
  },
];

const PLAN_ICONS = {
  free: User,
  creator: Zap,
  pro: Crown,
  agency: Building2,
};

const COMPARISON_FEATURES = [
  { feature: 'Monthly Generations', free: '10', creator: '100', pro: '500', agency: 'Unlimited' },
  { feature: 'AI Tools Access', free: '5 tools', creator: 'All 10', pro: 'All 10', agency: 'All 10' },
  { feature: 'Output Quality', free: 'Standard', creator: 'High', pro: 'Premium', agency: 'Premium+' },
  { feature: 'Save History', free: false, creator: true, pro: true, agency: true },
  { feature: 'Custom Tone', free: false, creator: true, pro: true, agency: true },
  { feature: 'API Access', free: false, creator: false, pro: true, agency: true },
  { feature: 'Team Seats', free: '1', creator: '1', pro: '3', agency: 'Unlimited' },
  { feature: 'Priority Support', free: false, creator: true, pro: true, agency: true },
  { feature: 'White-label', free: false, creator: false, pro: false, agency: true },
  { feature: 'Bulk Generation', free: false, creator: false, pro: true, agency: true },
  { feature: 'Custom AI Fine-tuning', free: false, creator: false, pro: false, agency: true },
  { feature: 'SLA Guarantee', free: false, creator: false, pro: false, agency: true },
];

export default function Pricing() {
  const [billingCycle, setBillingCycle] = useState<'monthly' | 'yearly'>('monthly');

  const getPrice = (price: number | null) => {
    if (price === null || price === 0) return price;
    return billingCycle === 'yearly' ? Math.floor(price * 0.8) : price;
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100">
      <Navbar />

      <div className="pt-24">
        {/* Hero */}
        <section className="py-20 text-center relative overflow-hidden">
          <div className="absolute inset-0 bg-gradient-hero grid-pattern" />
          <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[500px] h-[300px] bg-violet-500/10 blur-3xl rounded-full" />

          <div className="relative max-w-3xl mx-auto px-4">
            <Badge variant="purple" dot className="mb-6">Transparent Pricing</Badge>
            <h1 className="text-4xl sm:text-6xl font-extrabold text-white mb-6">
              Simple, <span className="gradient-text">Creator-Friendly</span> Pricing
            </h1>
            <p className="text-xl text-slate-400 mb-8">
              Start free. Scale as you grow. No hidden fees.
            </p>

            {/* Billing Toggle */}
            <div className="inline-flex items-center gap-4 p-1 rounded-xl bg-slate-900 border border-slate-800">
              <button
                onClick={() => setBillingCycle('monthly')}
                className={`px-5 py-2.5 rounded-lg text-sm font-medium transition-all cursor-pointer ${
                  billingCycle === 'monthly'
                    ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-500/30'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                Monthly
              </button>
              <button
                onClick={() => setBillingCycle('yearly')}
                className={`px-5 py-2.5 rounded-lg text-sm font-medium transition-all cursor-pointer flex items-center gap-2 ${
                  billingCycle === 'yearly'
                    ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-500/30'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                Yearly
                <Badge variant="green" className="text-xs py-0">Save 20%</Badge>
              </button>
            </div>
          </div>
        </section>

        {/* Pricing Cards */}
        <section className="py-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-6">
            {PRICING_PLANS.map(plan => {
              const PlanIcon = PLAN_ICONS[plan.id];
              const price = getPrice(plan.price);

              return (
                <div
                  key={plan.id}
                  className={`relative rounded-2xl border transition-all duration-300 ${
                    plan.highlighted
                      ? 'bg-gradient-to-b from-indigo-500/15 to-violet-500/5 border-indigo-500/50 shadow-2xl shadow-indigo-500/20 scale-105'
                      : 'bg-slate-900/60 border-slate-800/60 hover:border-slate-700'
                  }`}
                >
                  {/* Popular badge */}
                  {plan.badge && (
                    <div className="absolute -top-3 left-1/2 -translate-x-1/2">
                      <span className="px-4 py-1 rounded-full text-xs font-bold bg-gradient-to-r from-indigo-500 to-violet-500 text-white shadow-lg">
                        {plan.badge}
                      </span>
                    </div>
                  )}

                  <div className="p-6">
                    {/* Plan Header */}
                    <div className="flex items-center gap-3 mb-4">
                      <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${
                        plan.highlighted ? 'bg-indigo-500/20' : 'bg-slate-800'
                      }`}>
                        <PlanIcon className={`w-5 h-5 ${plan.highlighted ? 'text-indigo-400' : 'text-slate-400'}`} />
                      </div>
                      <div>
                        <h3 className="font-bold text-white">{plan.name}</h3>
                        <p className="text-xs text-slate-400">{plan.description}</p>
                      </div>
                    </div>

                    {/* Price */}
                    <div className="mb-6">
                      {price === 0 || price === null ? (
                        <div className="flex items-baseline gap-1">
                          <span className="text-4xl font-extrabold text-white">Free</span>
                          <span className="text-slate-400 text-sm">forever</span>
                        </div>
                      ) : (
                        <div className="flex items-baseline gap-1">
                          <span className="text-2xl font-bold text-slate-400">₹</span>
                          <span className="text-4xl font-extrabold text-white">{price}</span>
                          <span className="text-slate-400 text-sm">/{billingCycle === 'yearly' ? 'mo, billed yearly' : 'month'}</span>
                        </div>
                      )}
                      {billingCycle === 'yearly' && plan.price && plan.price > 0 && (
                        <p className="text-xs text-emerald-400 mt-1">
                          Save ₹{plan.price * 12 - (getPrice(plan.price) || 0) * 12}/year
                        </p>
                      )}
                      <p className="text-xs text-slate-500 mt-1">
                        {plan.generationsPerMonth === 'unlimited' ? 'Unlimited' : plan.generationsPerMonth} generations/month
                      </p>
                    </div>

                    {/* CTA Button */}
                    <Link to="/register">
                      <Button
                        fullWidth
                        variant={plan.highlighted ? 'primary' : 'secondary'}
                        className="mb-6"
                      >
                        {plan.price === 0 ? 'Start Free' : 'Get Started'}
                      </Button>
                    </Link>

                    {/* Features */}
                    <ul className="space-y-3">
                      {plan.features.map(feature => (
                        <li key={feature} className="flex items-start gap-2.5">
                          <Check className="w-4 h-4 text-emerald-400 flex-shrink-0 mt-0.5" />
                          <span className="text-sm text-slate-300">{feature}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>
              );
            })}
          </div>
        </section>

        {/* Feature Comparison Table */}
        <section className="py-20 max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl font-bold text-white text-center mb-12">Full Feature Comparison</h2>

          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-slate-800">
                  <th className="text-left py-4 pr-8 text-slate-400 font-medium text-sm">Feature</th>
                  {['Free', 'Creator', 'Pro', 'Agency'].map(p => (
                    <th key={p} className={`text-center py-4 px-4 text-sm font-bold ${p === 'Pro' ? 'text-indigo-300' : 'text-white'}`}>
                      {p}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {COMPARISON_FEATURES.map((row, i) => (
                  <tr key={row.feature} className={`border-b border-slate-800/50 ${i % 2 === 0 ? 'bg-slate-900/20' : ''}`}>
                    <td className="py-3 pr-8 text-sm text-slate-300">{row.feature}</td>
                    {[row.free, row.creator, row.pro, row.agency].map((val, j) => (
                      <td key={j} className="py-3 px-4 text-center">
                        {typeof val === 'boolean' ? (
                          val ? (
                            <Check className="w-4 h-4 text-emerald-400 mx-auto" />
                          ) : (
                            <X className="w-4 h-4 text-slate-700 mx-auto" />
                          )
                        ) : (
                          <span className={`text-sm ${j === 2 ? 'text-indigo-300 font-medium' : 'text-slate-300'}`}>{val}</span>
                        )}
                      </td>
                    ))}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </section>

        {/* FAQ */}
        <section className="py-20 bg-gradient-section">
          <div className="max-w-3xl mx-auto px-4">
            <h2 className="text-3xl font-bold text-white text-center mb-12">Frequently Asked Questions</h2>
            <div className="space-y-4">
              {FAQ.map((item) => (
                <GlassCard key={item.q} padding="md">
                  <h3 className="font-semibold text-white mb-2">{item.q}</h3>
                  <p className="text-slate-400 text-sm leading-relaxed">{item.a}</p>
                </GlassCard>
              ))}
            </div>
          </div>
        </section>

        {/* CTA */}
        <section className="py-20 text-center">
          <div className="max-w-2xl mx-auto px-4">
            <h2 className="text-4xl font-bold text-white mb-4">
              Still not sure? <span className="gradient-text">Try for Free.</span>
            </h2>
            <p className="text-slate-400 mb-8">10 free generations. No credit card. Cancel anytime.</p>
            <Link to="/register">
              <Button size="xl" icon={<Zap className="w-5 h-5 fill-white" />}>
                Get Started for Free
              </Button>
            </Link>
          </div>
        </section>
      </div>
    </div>
  );
}
