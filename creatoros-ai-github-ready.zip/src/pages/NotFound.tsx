// =========================================
// CreatorOS AI – 404 Not Found Page
// =========================================

import { Link } from 'react-router-dom';
import { Home, ArrowRight, Zap } from 'lucide-react';
import Button from '../components/ui/Button';

export default function NotFound() {
  return (
    <div className="min-h-screen bg-slate-950 flex items-center justify-center relative overflow-hidden">
      {/* Background */}
      <div className="absolute inset-0 grid-pattern" />
      <div className="absolute top-1/3 left-1/3 w-96 h-96 orb orb-indigo opacity-20" />
      <div className="absolute bottom-1/3 right-1/3 w-72 h-72 orb orb-blue opacity-15" style={{ animationDelay: '-3s' }} />

      <div className="relative text-center px-4 fade-in">
        {/* Logo */}
        <div className="flex items-center justify-center gap-2 mb-12">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-indigo-500 to-violet-600 flex items-center justify-center">
            <Zap className="w-5 h-5 text-white fill-white" />
          </div>
          <span className="font-bold text-xl">
            <span className="gradient-text">Creator</span><span className="text-white">OS AI</span>
          </span>
        </div>

        {/* 404 */}
        <div className="text-9xl font-black gradient-text mb-4 leading-none">404</div>
        <h1 className="text-3xl font-bold text-white mb-4">Page Not Found</h1>
        <p className="text-slate-400 text-lg mb-10 max-w-md mx-auto">
          Looks like this page got lost in the algorithm. Let's get you back to creating!
        </p>

        <div className="flex flex-col sm:flex-row gap-4 justify-center">
          <Link to="/">
            <Button size="lg" icon={<Home className="w-4 h-4" />}>
              Go Home
            </Button>
          </Link>
          <Link to="/dashboard">
            <Button size="lg" variant="secondary" iconRight={<ArrowRight className="w-4 h-4" />}>
              Open Dashboard
            </Button>
          </Link>
        </div>
      </div>
    </div>
  );
}
