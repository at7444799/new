// =========================================
// CreatorOS AI – App Context
// Global state management using React Context
// =========================================

import { createContext, useContext, useState, useCallback, ReactNode } from 'react';
import { User, HistoryItem, AppSettings, PlanType } from '../types';

interface AppContextType {
  // Auth state
  user: User | null;
  isAuthenticated: boolean;
  login: (email: string, password: string) => Promise<boolean>;
  register: (name: string, email: string, password: string) => Promise<boolean>;
  logout: () => void;
  updateUser: (updates: Partial<User>) => void;

  // History state
  history: HistoryItem[];
  addToHistory: (item: Omit<HistoryItem, 'id' | 'createdAt'>) => void;
  toggleSaved: (id: string) => void;
  clearHistory: () => void;
  deleteHistoryItem: (id: string) => void;

  // Settings
  settings: AppSettings;
  updateSettings: (updates: Partial<AppSettings>) => void;

  // UI state
  sidebarOpen: boolean;
  setSidebarOpen: (open: boolean) => void;

  // Generation tracking
  canGenerate: boolean;
  incrementGenerations: () => void;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

// Default mock user for demo purposes
const DEFAULT_USER: User = {
  id: 'user_001',
  email: 'demo@creatorosai.com',
  name: 'Alex Creator',
  plan: 'pro',
  generationsUsed: 34,
  generationsLimit: 200,
  createdAt: new Date().toISOString(),
};

// Default settings
const DEFAULT_SETTINGS: AppSettings = {
  aiProvider: 'mock', // Use mock by default until API key is added
  language: 'English',
  outputLength: 'medium',
  tone: 'professional',
};

// Plan generation limits
const PLAN_LIMITS: Record<PlanType, number> = {
  free: 10,
  creator: 100,
  pro: 500,
  agency: 9999,
};

export function AppProvider({ children }: { children: ReactNode }) {
  // Initialize user from localStorage for persistence
  const [user, setUser] = useState<User | null>(() => {
    try {
      const stored = localStorage.getItem('creatoros_user');
      return stored ? JSON.parse(stored) : DEFAULT_USER;
    } catch {
      return DEFAULT_USER;
    }
  });

  const [history, setHistory] = useState<HistoryItem[]>(() => {
    try {
      const stored = localStorage.getItem('creatoros_history');
      return stored ? JSON.parse(stored) : generateSampleHistory();
    } catch {
      return generateSampleHistory();
    }
  });

  const [settings, setSettings] = useState<AppSettings>(() => {
    try {
      const stored = localStorage.getItem('creatoros_settings');
      return stored ? JSON.parse(stored) : DEFAULT_SETTINGS;
    } catch {
      return DEFAULT_SETTINGS;
    }
  });

  const [sidebarOpen, setSidebarOpen] = useState(false);

  // Persist user to localStorage
  const persistUser = useCallback((u: User | null) => {
    if (u) localStorage.setItem('creatoros_user', JSON.stringify(u));
    else localStorage.removeItem('creatoros_user');
    setUser(u);
  }, []);

  // Persist history to localStorage
  const persistHistory = useCallback((h: HistoryItem[]) => {
    localStorage.setItem('creatoros_history', JSON.stringify(h.slice(0, 50))); // Keep last 50
    setHistory(h);
  }, []);

  // Auth functions
  const login = useCallback(async (email: string, _password: string): Promise<boolean> => {
    // Mock login – in production, call Supabase Auth here
    await new Promise(resolve => setTimeout(resolve, 1000));
    const mockUser: User = {
      ...DEFAULT_USER,
      email,
      name: email.split('@')[0].replace(/[._]/g, ' ').replace(/\b\w/g, c => c.toUpperCase()),
    };
    persistUser(mockUser);
    return true;
  }, [persistUser]);

  const register = useCallback(async (name: string, email: string, _password: string): Promise<boolean> => {
    // Mock register – in production, call Supabase Auth here
    await new Promise(resolve => setTimeout(resolve, 1200));
    const newUser: User = {
      id: `user_${Date.now()}`,
      email,
      name,
      plan: 'free',
      generationsUsed: 0,
      generationsLimit: PLAN_LIMITS.free,
      createdAt: new Date().toISOString(),
    };
    persistUser(newUser);
    return true;
  }, [persistUser]);

  const logout = useCallback(() => {
    persistUser(null);
    localStorage.removeItem('creatoros_history');
  }, [persistUser]);

  const updateUser = useCallback((updates: Partial<User>) => {
    setUser(prev => {
      if (!prev) return prev;
      const updated = { ...prev, ...updates };
      localStorage.setItem('creatoros_user', JSON.stringify(updated));
      return updated;
    });
  }, []);

  // History functions
  const addToHistory = useCallback((item: Omit<HistoryItem, 'id' | 'createdAt'>) => {
    const newItem: HistoryItem = {
      ...item,
      id: `hist_${Date.now()}`,
      createdAt: new Date().toISOString(),
    };
    setHistory(prev => {
      const updated = [newItem, ...prev];
      localStorage.setItem('creatoros_history', JSON.stringify(updated.slice(0, 50)));
      return updated;
    });
  }, []);

  const toggleSaved = useCallback((id: string) => {
    setHistory(prev => {
      const updated = prev.map(item =>
        item.id === id ? { ...item, saved: !item.saved } : item
      );
      localStorage.setItem('creatoros_history', JSON.stringify(updated));
      return updated;
    });
  }, []);

  const clearHistory = useCallback(() => {
    persistHistory([]);
  }, [persistHistory]);

  const deleteHistoryItem = useCallback((id: string) => {
    setHistory(prev => {
      const updated = prev.filter(item => item.id !== id);
      localStorage.setItem('creatoros_history', JSON.stringify(updated));
      return updated;
    });
  }, []);

  // Settings functions
  const updateSettings = useCallback((updates: Partial<AppSettings>) => {
    setSettings(prev => {
      const updated = { ...prev, ...updates };
      localStorage.setItem('creatoros_settings', JSON.stringify(updated));
      return updated;
    });
  }, []);

  // Generation tracking
  const canGenerate = user ? user.generationsUsed < user.generationsLimit : false;

  const incrementGenerations = useCallback(() => {
    setUser(prev => {
      if (!prev) return prev;
      const updated = { ...prev, generationsUsed: prev.generationsUsed + 1 };
      localStorage.setItem('creatoros_user', JSON.stringify(updated));
      return updated;
    });
  }, []);

  const value: AppContextType = {
    user,
    isAuthenticated: !!user,
    login,
    register,
    logout,
    updateUser,
    history,
    addToHistory,
    toggleSaved,
    clearHistory,
    deleteHistoryItem,
    settings,
    updateSettings,
    sidebarOpen,
    setSidebarOpen,
    canGenerate,
    incrementGenerations,
  };

  return <AppContext.Provider value={value}>{children}</AppContext.Provider>;
}

// Custom hook
export function useApp() {
  const context = useContext(AppContext);
  if (!context) throw new Error('useApp must be used within AppProvider');
  return context;
}

// Generate sample history data for demo
function generateSampleHistory(): HistoryItem[] {
  return [
    {
      id: 'hist_sample_1',
      toolId: 'youtube-title',
      toolName: 'YouTube Title Generator',
      input: 'How to make money with AI in 2024',
      output: '🔥 I Made $10,000 with AI in 30 Days (Step-by-Step Guide)\n💰 How AI is Making People RICH in 2024 (You Can Too!)\n🚀 The Secret AI Money Method NOBODY Is Talking About\n⚡ From $0 to $10K: My AI Income Journey Revealed\n🎯 Stop Working Hard – Let AI Make Money For You (2024)',
      createdAt: new Date(Date.now() - 86400000).toISOString(),
      saved: true,
    },
    {
      id: 'hist_sample_2',
      toolId: 'viral-hook',
      toolName: 'Viral Hook Generator',
      input: 'Productivity tips for entrepreneurs',
      output: '"I wasted 3 years being "busy" before I discovered this one system..."\n\n"What if I told you that 90% of your to-do list is killing your productivity?"\n\n"The most successful entrepreneurs don\'t work harder. They\'ve mastered this instead."\n\n"Stop checking your phone first thing in the morning. Here\'s what to do instead."',
      createdAt: new Date(Date.now() - 172800000).toISOString(),
      saved: false,
    },
    {
      id: 'hist_sample_3',
      toolId: 'instagram-caption',
      toolName: 'Instagram Caption Generator',
      input: 'Morning coffee and journaling routine',
      output: '☕ 5:30 AM. The world is still asleep.\n\nThis is my sacred hour.\nNo notifications. No emails. Just me, my coffee, and my thoughts on paper.\n\nI\'ve been journaling for 3 years now and it\'s the single habit that changed everything.\n\nDM me "JOURNAL" and I\'ll send you my free morning routine guide 📖\n\n#MorningRoutine #JournalingLife #ProductiveMorning #MindfulLiving #CreatorLife',
      createdAt: new Date(Date.now() - 259200000).toISOString(),
      saved: true,
    },
  ];
}
