// =========================================
// CreatorOS AI – Type Definitions
// =========================================

export type PlanType = 'free' | 'creator' | 'pro' | 'agency';

export type ToolId =
  | 'shorts-script'
  | 'viral-hook'
  | 'youtube-title'
  | 'seo-description'
  | 'hashtag-generator'
  | 'thumbnail-prompt'
  | 'product-ad-copy'
  | 'blog-post'
  | 'instagram-caption'
  | 'content-calendar';

export interface User {
  id: string;
  email: string;
  name: string;
  avatar?: string;
  plan: PlanType;
  generationsUsed: number;
  generationsLimit: number;
  createdAt: string;
}

export interface HistoryItem {
  id: string;
  toolId: ToolId;
  toolName: string;
  input: string;
  output: string;
  createdAt: string;
  saved: boolean;
}

export interface Tool {
  id: ToolId;
  name: string;
  description: string;
  icon: string;
  category: string;
  inputLabel: string;
  inputPlaceholder: string;
  inputType: 'text' | 'textarea';
  color: string;
  bgColor: string;
  badge?: string;
}

export interface PricingPlan {
  id: PlanType;
  name: string;
  price: number | null;
  period: string;
  description: string;
  features: string[];
  generationsPerMonth: number | 'unlimited';
  highlighted: boolean;
  badge?: string;
}

export interface GenerateRequest {
  toolId: ToolId;
  input: string;
  additionalOptions?: Record<string, string>;
}

export interface GenerateResponse {
  output: string;
  tokensUsed?: number;
  model?: string;
}

export interface AppSettings {
  aiProvider: 'mock' | 'openai' | 'claude' | 'deepseek' | 'nvidia';
  apiKey?: string;
  language: string;
  outputLength: 'short' | 'medium' | 'long';
  tone: string;
}
