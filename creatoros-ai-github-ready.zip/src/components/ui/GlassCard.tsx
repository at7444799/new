// =========================================
// CreatorOS AI – GlassCard Component
// Glassmorphism card container
// =========================================

import { ReactNode } from 'react';
import { clsx } from 'clsx';

interface GlassCardProps {
  children: ReactNode;
  className?: string;
  hover?: boolean;
  padding?: 'none' | 'sm' | 'md' | 'lg' | 'xl';
  glow?: boolean;
  onClick?: () => void;
}

export default function GlassCard({
  children,
  className,
  hover = false,
  padding = 'md',
  glow = false,
  onClick,
}: GlassCardProps) {
  const paddingMap = {
    none: '',
    sm: 'p-4',
    md: 'p-6',
    lg: 'p-8',
    xl: 'p-10',
  };

  return (
    <div
      onClick={onClick}
      className={clsx(
        'rounded-2xl border',
        'bg-slate-900/60 backdrop-blur-xl',
        'border-indigo-500/20',
        paddingMap[padding],
        hover && 'transition-all duration-300 hover:border-indigo-500/50 hover:-translate-y-1 hover:shadow-xl hover:shadow-indigo-500/10 cursor-pointer',
        glow && 'shadow-lg shadow-indigo-500/10',
        onClick && 'cursor-pointer',
        className
      )}
    >
      {children}
    </div>
  );
}
