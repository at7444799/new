// =========================================
// CreatorOS AI – Badge Component
// =========================================

import { ReactNode } from 'react';
import { clsx } from 'clsx';

type BadgeVariant = 'blue' | 'purple' | 'green' | 'yellow' | 'red' | 'gray' | 'cyan';

interface BadgeProps {
  children: ReactNode;
  variant?: BadgeVariant;
  className?: string;
  dot?: boolean;
}

const variants: Record<BadgeVariant, string> = {
  blue: 'bg-blue-500/10 text-blue-400 border-blue-500/30',
  purple: 'bg-violet-500/10 text-violet-400 border-violet-500/30',
  green: 'bg-emerald-500/10 text-emerald-400 border-emerald-500/30',
  yellow: 'bg-yellow-500/10 text-yellow-400 border-yellow-500/30',
  red: 'bg-red-500/10 text-red-400 border-red-500/30',
  gray: 'bg-slate-500/10 text-slate-400 border-slate-500/30',
  cyan: 'bg-cyan-500/10 text-cyan-400 border-cyan-500/30',
};

const dotColors: Record<BadgeVariant, string> = {
  blue: 'bg-blue-400',
  purple: 'bg-violet-400',
  green: 'bg-emerald-400',
  yellow: 'bg-yellow-400',
  red: 'bg-red-400',
  gray: 'bg-slate-400',
  cyan: 'bg-cyan-400',
};

export default function Badge({ children, variant = 'blue', className, dot = false }: BadgeProps) {
  return (
    <span
      className={clsx(
        'inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-semibold border uppercase tracking-wider',
        variants[variant],
        className
      )}
    >
      {dot && <span className={clsx('w-1.5 h-1.5 rounded-full animate-pulse', dotColors[variant])} />}
      {children}
    </span>
  );
}
