// =========================================
// CreatorOS AI – Progress Bar Component
// =========================================

import { clsx } from 'clsx';

interface ProgressBarProps {
  value: number;
  max: number;
  label?: string;
  showLabel?: boolean;
  size?: 'sm' | 'md' | 'lg';
  color?: 'indigo' | 'emerald' | 'violet' | 'cyan' | 'red';
  className?: string;
}

const colors = {
  indigo: 'from-indigo-500 to-violet-500',
  emerald: 'from-emerald-500 to-teal-500',
  violet: 'from-violet-500 to-pink-500',
  cyan: 'from-cyan-500 to-blue-500',
  red: 'from-red-500 to-orange-500',
};

const sizes = {
  sm: 'h-1',
  md: 'h-2',
  lg: 'h-3',
};

export default function ProgressBar({
  value,
  max,
  label,
  showLabel = true,
  size = 'md',
  color = 'indigo',
  className,
}: ProgressBarProps) {
  const percentage = Math.min(Math.max((value / max) * 100, 0), 100);

  return (
    <div className={className}>
      {showLabel && (
        <div className="flex justify-between text-xs text-slate-400 mb-1.5">
          <span>{label || 'Progress'}</span>
          <span>{Math.round(percentage)}%</span>
        </div>
      )}
      <div className={clsx('w-full bg-slate-800/60 rounded-full overflow-hidden', sizes[size])}>
        <div
          className={clsx('h-full rounded-full bg-gradient-to-r transition-all duration-700 ease-out', colors[color])}
          style={{ width: `${percentage}%` }}
        />
      </div>
    </div>
  );
}
