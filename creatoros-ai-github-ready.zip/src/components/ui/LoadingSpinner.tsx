// =========================================
// CreatorOS AI – Loading Spinner Component
// =========================================

import { clsx } from 'clsx';

interface LoadingSpinnerProps {
  size?: 'sm' | 'md' | 'lg';
  className?: string;
  text?: string;
}

export default function LoadingSpinner({ size = 'md', className, text }: LoadingSpinnerProps) {
  const sizes = {
    sm: 'w-4 h-4',
    md: 'w-8 h-8',
    lg: 'w-12 h-12',
  };

  return (
    <div className={clsx('flex flex-col items-center justify-center gap-3', className)}>
      <div className="relative">
        <div className={clsx('rounded-full border-2 border-indigo-500/20 animate-spin', sizes[size])}>
          <div className={clsx('absolute inset-0 rounded-full border-2 border-transparent border-t-indigo-500', sizes[size])} />
        </div>
        <div className={clsx('absolute inset-0 rounded-full', sizes[size])}
          style={{ background: 'radial-gradient(circle, rgba(99,102,241,0.2), transparent)', animation: 'pulse 1.5s ease-in-out infinite' }} />
      </div>
      {text && <p className="text-sm text-slate-400 animate-pulse">{text}</p>}
    </div>
  );
}

// AI Generating Animation
export function AIGeneratingAnimation() {
  return (
    <div className="flex flex-col items-center justify-center py-12 gap-6">
      {/* Orbiting dots */}
      <div className="relative w-24 h-24">
        <div className="absolute inset-0 rounded-full border border-indigo-500/20 animate-spin" style={{ animationDuration: '3s' }}>
          <div className="absolute top-0 left-1/2 -translate-x-1/2 -translate-y-1/2 w-3 h-3 rounded-full bg-indigo-500 shadow-lg shadow-indigo-500/50" />
        </div>
        <div className="absolute inset-2 rounded-full border border-violet-500/20 animate-spin" style={{ animationDuration: '2s', animationDirection: 'reverse' }}>
          <div className="absolute top-0 left-1/2 -translate-x-1/2 -translate-y-1/2 w-2 h-2 rounded-full bg-violet-500 shadow-lg shadow-violet-500/50" />
        </div>
        <div className="absolute inset-4 rounded-full border border-cyan-500/20 animate-spin" style={{ animationDuration: '1.5s' }}>
          <div className="absolute top-0 left-1/2 -translate-x-1/2 -translate-y-1/2 w-1.5 h-1.5 rounded-full bg-cyan-400 shadow-lg shadow-cyan-400/50" />
        </div>
        {/* Center pulse */}
        <div className="absolute inset-0 flex items-center justify-center">
          <div className="w-6 h-6 rounded-full bg-gradient-to-br from-indigo-500 to-violet-500 animate-pulse shadow-lg shadow-indigo-500/50" />
        </div>
      </div>

      {/* Typing dots */}
      <div className="flex flex-col items-center gap-2">
        <p className="text-slate-300 font-medium">AI is generating your content</p>
        <div className="flex gap-1">
          {[0, 1, 2].map(i => (
            <div
              key={i}
              className="w-2 h-2 rounded-full bg-indigo-500"
              style={{ animation: `bounce 1s ease-in-out ${i * 0.2}s infinite` }}
            />
          ))}
        </div>
        <p className="text-slate-500 text-sm">This usually takes 2-5 seconds...</p>
      </div>
    </div>
  );
}
