// =========================================
// CreatorOS AI – Dashboard Layout
// Wrapper for all authenticated pages
// =========================================

import { ReactNode } from 'react';
import { Menu, Bell } from 'lucide-react';
import Sidebar from './Sidebar';
import { useApp } from '../../context/AppContext';
import { Link } from 'react-router-dom';

interface DashboardLayoutProps {
  children: ReactNode;
  title?: string;
  subtitle?: string;
}

export default function DashboardLayout({ children, title, subtitle }: DashboardLayoutProps) {
  const { setSidebarOpen, sidebarOpen, user } = useApp();

  return (
    <div className="min-h-screen bg-slate-950 flex">
      {/* Sidebar */}
      <Sidebar onClose={() => setSidebarOpen(false)} />

      {/* Mobile overlay */}
      {sidebarOpen && (
        <div
          className="fixed inset-0 z-30 bg-black/60 backdrop-blur-sm lg:hidden"
          onClick={() => setSidebarOpen(false)}
        />
      )}

      {/* Main Content */}
      <div className="flex-1 lg:ml-64 min-h-screen flex flex-col">
        {/* Top Header */}
        <header className="sticky top-0 z-20 flex items-center gap-4 px-4 sm:px-6 py-4 border-b border-slate-800/50 bg-slate-950/80 backdrop-blur-xl">
          {/* Mobile menu button */}
          <button
            onClick={() => setSidebarOpen(!sidebarOpen)}
            className="lg:hidden p-2 rounded-lg text-slate-400 hover:text-white hover:bg-white/5 transition-colors cursor-pointer"
          >
            <Menu className="w-5 h-5" />
          </button>

          {/* Title */}
          <div className="flex-1">
            {title && (
              <div>
                <h1 className="text-lg font-bold text-white">{title}</h1>
                {subtitle && <p className="text-sm text-slate-400">{subtitle}</p>}
              </div>
            )}
          </div>

          {/* Right side */}
          <div className="flex items-center gap-2">
            {/* Generations indicator */}
            {user && (
              <div className="hidden sm:flex items-center gap-2 px-3 py-1.5 rounded-lg bg-indigo-500/10 border border-indigo-500/20">
                <div className="w-1.5 h-1.5 rounded-full bg-indigo-400 animate-pulse" />
                <span className="text-xs text-indigo-300 font-medium">
                  {user.generationsLimit - user.generationsUsed} left
                </span>
              </div>
            )}

            {/* Notifications */}
            <button className="relative p-2 rounded-lg text-slate-400 hover:text-white hover:bg-white/5 transition-colors cursor-pointer">
              <Bell className="w-4 h-4" />
              <span className="absolute top-1.5 right-1.5 w-1.5 h-1.5 rounded-full bg-indigo-500" />
            </button>

            {/* User avatar */}
            {user && (
              <Link to="/settings">
                <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-indigo-500 to-violet-600 flex items-center justify-center text-sm font-bold text-white cursor-pointer hover:opacity-80 transition-opacity">
                  {user.name.charAt(0).toUpperCase()}
                </div>
              </Link>
            )}
          </div>
        </header>

        {/* Page Content */}
        <main className="flex-1 p-4 sm:p-6">
          {children}
        </main>

        {/* Footer */}
        <footer className="px-6 py-4 border-t border-slate-800/50 text-center">
          <p className="text-xs text-slate-600">
            CreatorOS AI © 2024 · <Link to="/pricing" className="hover:text-slate-400 transition-colors">Upgrade Plan</Link>
          </p>
        </footer>
      </div>
    </div>
  );
}
