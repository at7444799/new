// =========================================
// CreatorOS AI – Dashboard Sidebar
// Navigation for authenticated pages
// =========================================

import { Link, useLocation, useNavigate } from 'react-router-dom';
import {
  LayoutDashboard, History, Settings, LogOut, Zap,
  Film, TrendingUp, PlayCircle, Search, Hash, Image,
  Megaphone, FileText, Camera, Calendar, X, Crown, ChevronRight
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { clsx } from 'clsx';

const TOOL_NAV = [
  { id: 'shorts-script', label: 'Shorts Script', icon: Film, color: 'text-red-400' },
  { id: 'viral-hook', label: 'Viral Hook', icon: TrendingUp, color: 'text-yellow-400' },
  { id: 'youtube-title', label: 'YouTube Title', icon: PlayCircle, color: 'text-red-400' },
  { id: 'seo-description', label: 'SEO Description', icon: Search, color: 'text-emerald-400' },
  { id: 'hashtag-generator', label: 'Hashtag Generator', icon: Hash, color: 'text-violet-400' },
  { id: 'thumbnail-prompt', label: 'Thumbnail Prompt', icon: Image, color: 'text-cyan-400' },
  { id: 'product-ad-copy', label: 'Product Ad Copy', icon: Megaphone, color: 'text-orange-400' },
  { id: 'blog-post', label: 'Blog Post', icon: FileText, color: 'text-indigo-400' },
  { id: 'instagram-caption', label: 'Instagram Caption', icon: Camera, color: 'text-pink-400' },
  { id: 'content-calendar', label: 'Content Calendar', icon: Calendar, color: 'text-teal-400' },
];

const MAIN_NAV = [
  { href: '/dashboard', label: 'Dashboard', icon: LayoutDashboard },
  { href: '/history', label: 'History', icon: History },
  { href: '/settings', label: 'Settings', icon: Settings },
];

interface SidebarProps {
  onClose?: () => void;
}

export default function Sidebar({ onClose }: SidebarProps) {
  const location = useLocation();
  const navigate = useNavigate();
  const { user, logout, sidebarOpen } = useApp();

  const handleLogout = () => {
    logout();
    navigate('/');
  };

  const isActive = (href: string) => location.pathname === href;
  const isToolActive = (id: string) => location.pathname === `/tool/${id}`;

  return (
    <aside className={clsx(
      'sidebar fixed left-0 top-0 bottom-0 w-64 flex flex-col z-40',
      'lg:translate-x-0 transition-transform duration-300',
      sidebarOpen ? 'translate-x-0' : '-translate-x-full lg:translate-x-0'
    )}>
      {/* Logo */}
      <div className="flex items-center justify-between p-5 border-b border-slate-800/50">
        <Link to="/" className="flex items-center gap-2.5 group">
          <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-indigo-500 to-violet-600 flex items-center justify-center shadow-lg shadow-indigo-500/30">
            <Zap className="w-4 h-4 text-white fill-white" />
          </div>
          <span className="font-bold text-lg">
            <span className="gradient-text">Creator</span>
            <span className="text-white">OS</span>
          </span>
        </Link>
        {onClose && (
          <button onClick={onClose} className="lg:hidden p-1 rounded-lg text-slate-500 hover:text-white hover:bg-white/5 cursor-pointer">
            <X className="w-4 h-4" />
          </button>
        )}
      </div>

      {/* User Info */}
      {user && (
        <div className="p-4 border-b border-slate-800/50">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-indigo-500 to-violet-600 flex items-center justify-center text-sm font-bold text-white flex-shrink-0">
              {user.name.charAt(0).toUpperCase()}
            </div>
            <div className="min-w-0 flex-1">
              <p className="text-sm font-medium text-white truncate">{user.name}</p>
              <div className="flex items-center gap-1.5">
                <span className={clsx('text-xs px-1.5 py-0.5 rounded font-medium capitalize', {
                  'plan-free': user.plan === 'free',
                  'plan-creator': user.plan === 'creator',
                  'plan-pro': user.plan === 'pro',
                  'plan-agency': user.plan === 'agency',
                })}>
                  {user.plan}
                </span>
              </div>
            </div>
          </div>

          {/* Usage bar */}
          <div className="mt-3">
            <div className="flex justify-between text-xs text-slate-500 mb-1">
              <span>Generations</span>
              <span>{user.generationsUsed}/{user.generationsLimit}</span>
            </div>
            <div className="progress-bar h-1.5">
              <div
                className="progress-fill h-full"
                style={{ width: `${Math.min((user.generationsUsed / user.generationsLimit) * 100, 100)}%` }}
              />
            </div>
          </div>
        </div>
      )}

      {/* Scrollable Navigation */}
      <div className="flex-1 overflow-y-auto py-4 px-3 space-y-1">
        {/* Main Nav */}
        {MAIN_NAV.map(item => (
          <Link
            key={item.href}
            to={item.href}
            onClick={onClose}
            className={clsx(
              'flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium transition-all duration-200',
              isActive(item.href)
                ? 'bg-indigo-500/15 text-indigo-300 border border-indigo-500/30'
                : 'text-slate-400 hover:text-white hover:bg-white/5'
            )}
          >
            <item.icon className="w-4 h-4 flex-shrink-0" />
            {item.label}
            {isActive(item.href) && <ChevronRight className="w-3.5 h-3.5 ml-auto" />}
          </Link>
        ))}

        {/* Divider */}
        <div className="pt-4 pb-2">
          <p className="text-xs text-slate-600 uppercase tracking-wider font-semibold px-3">AI Tools</p>
        </div>

        {/* Tools Nav */}
        {TOOL_NAV.map(tool => (
          <Link
            key={tool.id}
            to={`/tool/${tool.id}`}
            onClick={onClose}
            className={clsx(
              'flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium transition-all duration-200',
              isToolActive(tool.id)
                ? 'bg-indigo-500/15 text-white border border-indigo-500/30'
                : 'text-slate-500 hover:text-slate-300 hover:bg-white/5'
            )}
          >
            <tool.icon className={clsx('w-4 h-4 flex-shrink-0', isToolActive(tool.id) ? tool.color : '')} />
            <span className="truncate">{tool.label}</span>
          </Link>
        ))}
      </div>

      {/* Bottom Section */}
      <div className="p-3 border-t border-slate-800/50 space-y-2">
        {/* Upgrade prompt for free users */}
        {user?.plan === 'free' && (
          <Link to="/pricing" className="block">
            <div className="flex items-center gap-2 px-3 py-2.5 rounded-xl bg-gradient-to-r from-indigo-500/15 to-violet-500/10 border border-indigo-500/30 hover:border-indigo-500/50 transition-all cursor-pointer">
              <Crown className="w-4 h-4 text-yellow-400" />
              <div>
                <p className="text-xs font-semibold text-indigo-300">Upgrade Plan</p>
                <p className="text-xs text-slate-500">Get unlimited access</p>
              </div>
            </div>
          </Link>
        )}

        {/* Logout */}
        <button
          onClick={handleLogout}
          className="flex items-center gap-3 w-full px-3 py-2.5 rounded-xl text-sm font-medium text-slate-500 hover:text-red-400 hover:bg-red-500/10 transition-all duration-200 cursor-pointer"
        >
          <LogOut className="w-4 h-4" />
          Sign Out
        </button>
      </div>
    </aside>
  );
}
